#!/bin/bash
set -e
cp .npmrc ~/.npmrc
export NPM_TOKEN=$NPM_TOKEN
export AWS_ACCESS_KEY_ID=$(eval "echo \${AWS_${1}_ID}")
export AWS_SECRET_ACCESS_KEY=$(eval "echo \${AWS_${1}_SECRET}")
echo "$EMVIO_CONFIG_ENV"
npm install
npm run deploy-resources
npm run lint
npm run deploy
