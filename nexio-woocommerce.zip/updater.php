<?php

class NexioUpdater {
    protected $file;
    protected $plugin;
    protected $active;

    private $username;
    private $repository;
    //private $access_token;
    private $github_response;
    private $basename;
    private $slug;

    public function __construct( $file ) {
        $this->file = $file;
        add_action( 'admin_init', array( $this, 'set_plugin_properties' ) );
        return $this;
    }

    public function initialize() {

        add_filter( 'site_transient_update_plugins',array( $this, 'modify_transient' ) );
        add_filter( 'transient_update_plugins', array( $this, 'modify_transient' ) );

        add_filter( 'plugins_api', array( $this, 'plugin_popup' ), 10, 3);
        add_filter( 'upgrader_post_install', array( $this, 'after_install' ), 10, 3 );

    }

    public function set_plugin_properties() {
        $this->plugin   = get_plugin_data( $this->file );
        $this->basename = plugin_basename( $this->file );
        $this->active   = is_plugin_active( $this->basename );
        $this->slug = $this->basename;
    }

    public function set_username( $username ) {
        $this->username = $username;
    }

    public function set_repository( $repository ) {
        $this->repository = $repository;
    }

    public function set_basename( $basename ) {
        $this->basename = $basename;
    }

    private function get_repository_info() {
        if ( is_null( $this->github_response ) ) { // Do we have a response?
            $request_uri = sprintf( 'https://api.github.com/repos/%s/%s/releases', $this->username, $this->repository ); // Build URI
            $response = json_decode( wp_remote_retrieve_body( wp_remote_get( $request_uri ) ), true ); // Get JSON and parse it
            if( is_array( $response ) ) { // If it is an array
                $response = current( $response ); // Get the first item
            }
            $this->github_response = $response; // Set it to our property
        }
    }

    public function modify_transient( $update_plugins ) {
        if ( ! is_object( $update_plugins ) ){
            return $update_plugins;
        }

        if ( ! isset( $update_plugins->response ) || ! is_array( $update_plugins->response ) ){
            $update_plugins->response = array();
        }

        if( $checked = $update_plugins->checked ) { // Did WordPress check for updates?
            $this->get_repository_info();
            $out_of_date = version_compare($this->github_response['tag_name'], $checked[$this->basename], 'gt'); // Check if we're out of date

            if ($out_of_date == 1) {
                $install_directory = basename(dirname(__FILE__));

                $package = 'https://github.com/nexiopay/'.$this->repository.'/archive/refs/tags/'.$this->github_response['tag_name'].".zip";
                $url = 'https://github.com/nexiopay/'.$this->repository;

                $update_plugins->response[$install_directory.'/nexio-init.php'] = (object)array(
                    'slug' => $this->slug,
                    'new_version' => $this->github_response['tag_name'],
                    'url' => $url,
                    'package' => $package
                );
            }
        }

        return $update_plugins;
    }

    public function plugin_popup( $result, $action, $args ) {
        error_log("(".__LINE__.")".__METHOD__." result==>".print_r($result, true)."\n");
        error_log("(".__LINE__.")".__METHOD__." args==>".print_r($args, true)."\n");
        error_log("(".__LINE__.")".__METHOD__." action==>".print_r($action, true)."\n");
        if( ! empty( $args->slug ) ) {
            if( $args->slug == $this->slug ) {
                $this->get_repository_info();
                $plugin = array(
                    'name'              => $this->plugin["Name"],
                    'slug'              => $this->basename,
                    'version'           => $this->github_response['tag_name'],
                    'author'            => $this->plugin["AuthorName"],
                    'author_profile'    => $this->plugin["AuthorURI"],
                    'last_updated'      => $this->github_response['published_at'],
                    'homepage'          => $this->plugin["PluginURI"],
                    'short_description' => $this->plugin["Description"],
                    'sections'          => array(
                        'Description'   => $this->plugin["Description"],
                        'Updates'       => $this->github_response['body'],
                    ),
                    'download_link'     => $this->github_response['zipball_url']
                );
                return (object) $plugin;
            }
        }
        return $result;
    }

    public function after_install( $response, $hook_extra, $result ) {
        global $wp_filesystem; // Get global FS object

        $install_directory = plugin_dir_path( $this->file ); // Our plugin directory
        error_log("(".__LINE__.")".__METHOD__." install_directory==>".$install_directory."\n");
        $zipFile = $result['destination']."/nexio-woocommerce.zip";

        $zip = new ZipArchive();
        $x = $zip->open($zipFile);
        error_log("(".__LINE__.")".__METHOD__." just opened zip\n");

        if ($x === true) {
            $zip->extractTo($result['destination']);
            $zip->close();
        }


        #-----------------------------------------------------------------------------
        error_log("(".__LINE__.")".__METHOD__." ONE LAST ==>before extra\n");
        $p_tmp = get_plugins('/' . $result['destination_name']);
        $p_key = array_keys( $p_tmp );

        $pre = ! empty( $result['destination_name'] ) ? $result['destination_name'] . '/' : '';

        $plugin = $pre . $p_key[0];
        $plugins = get_option('active_plugins');

        if( ! in_array( $plugin, $plugins ) ){
            array_push( $plugins, $plugin );
            update_option( 'active_plugins', $plugins );
            echo __('Plugin erfolgreich aktiviert');
        } else {
            echo __('Plugin konnte nicht aktiviert werden');
        }

        unset( $p_tmp, $p_key, $pre, $plugin, $plugins );
        error_log("(".__LINE__.")".__METHOD__." ONE LAST ==>after extra\n");

        error_log("(".__LINE__.")".__METHOD__." ==>COMPLETE\n");
        error_log("(".__LINE__.")".__METHOD__." ==>".print_r($result, true)."\n");
        return $result;
    }
}