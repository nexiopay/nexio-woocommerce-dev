<?php

class NexioUpdater {
    protected $file;
    protected $plugin;
    protected $active;

    private $username;
    private $repository;
    //private $access_token;
    private $github_response;
    private $basename;
    private $slug;

    public function __construct( $file ) {
        $this->file = $file;
        add_action( 'admin_init', array( $this, 'set_plugin_properties' ) );
        return $this;
    }

    public function initialize() {

        add_filter( 'site_transient_update_plugins',array( $this, 'modify_transient' ) );
        add_filter( 'transient_update_plugins', array( $this, 'modify_transient' ) );

        add_filter( 'plugins_api', array( $this, 'plugin_popup' ), 10, 3);
        add_filter( 'upgrader_post_install', array( $this, 'after_install' ), 10, 3 );

    }

    public function set_plugin_properties() {
        $this->plugin   = get_plugin_data( $this->file );
        $this->basename = plugin_basename( $this->file );
        $this->active   = is_plugin_active( $this->basename );
        $this->slug = $this->basename;
    }

    public function set_username( $username ) {
        $this->username = $username;
    }

    public function set_repository( $repository ) {
        $this->repository = $repository;
    }

//    public function set_access_token( $access_token ) {
//        $this->access_token = $access_token;
//    }

    public function set_basename( $basename ) {
        $this->basename = $basename;
    }

    private function get_repository_info() {
        if ( is_null( $this->github_response ) ) { // Do we have a response?
            $request_uri = sprintf( 'https://api.github.com/repos/%s/%s/releases', $this->username, $this->repository ); // Build URI
//            $response = json_decode( wp_remote_retrieve_body( wp_remote_get( $request_uri, array(
//                'headers'     => array(
//                    'Authorization' => 'token ' . $this->access_token
//                )
//            ) ) ), true ); // Get JSON and parse it
            $response = json_decode( wp_remote_retrieve_body( wp_remote_get( $request_uri ) ), true ); // Get JSON and parse it
            if( is_array( $response ) ) { // If it is an array
                $response = current( $response ); // Get the first item
            }

            $this->github_response = $response; // Set it to our property
        }
    }

    public function modify_transient( $update_plugins ) {
        error_log("(".__LINE__.")".__METHOD__." transient=>\n");
        if ( ! is_object( $update_plugins ) )
            return $update_plugins;

        if ( ! isset( $update_plugins->response ) || ! is_array( $update_plugins->response ) )
            $update_plugins->response = array();

        error_log("(".__LINE__.")".__METHOD__." ==>\n");
        if( $checked = $update_plugins->checked ) { // Did WordPress check for updates?
            $this->get_repository_info();

            error_log("(".__LINE__.")".__METHOD__." ==>".print_r($this->github_response, true)."\n");
            error_log("(" . __LINE__ . ")" . __METHOD__ . " Comparing ==>" . $this->github_response['tag_name'] . " To--> " . $checked[$this->basename] . "\n");

            $out_of_date = version_compare($this->github_response['tag_name'], $checked[$this->basename], 'gt'); // Check if we're out of date
            error_log("(".__LINE__.")".__METHOD__." out_of_date==>".$out_of_date."\n");

            if ($out_of_date == 1) {
                error_log("(" . __LINE__ . ")" . __METHOD__ . " ==>MARKED AS OUTOF DATE\n");
                $install_directory = basename(dirname(__FILE__));

                $package = 'https://github.com/nexiopay/'.$this->repository.'/archive/refs/tags/'.$this->github_response['tag_name'].".zip";
                $url = 'https://github.com/nexiopay/'.$this->repository;

                error_log("(".__LINE__.")".__METHOD__." package==>".$package."\n");
                error_log("(".__LINE__.")".__METHOD__." url==>".$url."\n");
                $update_plugins->response[$install_directory.'/nexio-init.php'] = (object)array(
                    'slug' => $this->slug,
                    'new_version' => $this->github_response['tag_name'],
                    'url' => $url,
                    'package' => $package
                );
            }
        }

        return $update_plugins;
    }

    public function plugin_popup( $result, $action, $args ) {
        error_log("(".__LINE__.")".__METHOD__."  args->slug==>". $args->slug."\n");
        if( ! empty( $args->slug ) ) { // If there is a slug
            error_log("(".__LINE__.")".__METHOD__." ==>\n");
            if( $args->slug == $this->slug ) {
                error_log("(".__LINE__.")".__METHOD__." ==>\n");
                $this->get_repository_info(); // Get our repo info
                // Set it to an array
                $plugin = array(
                    'name'              => $this->plugin["Name"],
                    'slug'              => $this->basename,
                    'version'           => $this->github_response['tag_name'],
                    'author'            => $this->plugin["AuthorName"],
                    'author_profile'    => $this->plugin["AuthorURI"],
                    'last_updated'      => $this->github_response['published_at'],
                    'homepage'          => $this->plugin["PluginURI"],
                    'short_description' => $this->plugin["Description"],
                    'sections'          => array(
                        'Description'   => $this->plugin["Description"],
                        'Updates'       => $this->github_response['body'],
                    ),
                    'download_link'     => $this->github_response['zipball_url']
                );
                error_log("(".__LINE__.")".__METHOD__." ==>".print_r($plugin, true)."\n");
                return (object) $plugin; // Return the data
            }
        }
        error_log("(".__LINE__.")".__METHOD__." ==>".print_r($result, true)."\n");
        return $result;
    }

    public function after_install( $response, $hook_extra, $result ) {
        global $wp_filesystem; // Get global FS object

        $install_directory = plugin_dir_path( $this->file ); // Our plugin directory
        error_log("(".__LINE__.")".__METHOD__." install_directory==>".$install_directory."\n");
        $zipFile = $result['destination']."/nexio-woocommerce.zip";
        error_log("(".__LINE__.")".__METHOD__." 1 zipFile==>".$zipFile."\n");
        error_log("(".__LINE__.")".__METHOD__." 2 zipFile==>".file_exists($zipFile) ? "FILE EXISTS" : "FILE DOES NOT EXIST" ."\n");

        $zip = new ZipArchive();
        $x = $zip->open($zipFile);
        error_log("(".__LINE__.")".__METHOD__." just opened zip\n");

        if ($x === true) {
            error_log("(".__LINE__.")".__METHOD__." extracting \n");
            $zip->extractTo($result['destination']);
            $zip->close();
        }else{
            error_log("(".__LINE__.")".__METHOD__." Not Extracting \n");
        }

        error_log("(".__LINE__.")".__METHOD__." ==>".$this->active ? "is active" : "is NOT active"."\n");
        if ( $this->active ) { // If it was active
            error_log("(".__LINE__.")".__METHOD__." activating==>". $this->basename ."\n");
            $new_directory = $result[destination_name].'/nexio-init.php';
            error_log("(".__LINE__.")".__METHOD__." activating new_directory==>". $new_directory ."\n");
            activate_plugin( $new_directory ); // Reactivate
        }
        error_log("(".__LINE__.")".__METHOD__." ==>COMPLETE\n");
        return $result;
    }
}