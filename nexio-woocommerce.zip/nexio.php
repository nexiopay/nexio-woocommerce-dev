<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * CMS_Gateway_Nexio class.
 *
 * @extends WC_Payment_Gateway
 */
class Nexio extends WC_Payment_Gateway_CC
{
    /**
     * Nexio plugin version.
     *
     * @var string
     */
    public $version = '1.4.8';

    /**
     * Nexio Payment API endpoint
     *
     * @var string
     */
    public $api_url = 'https://api.nexiopay.com/pay/';

    /**
     * Testing mode
     *
     * @var boolean
     */
    public $developmentMode;

    /**
     * Cardholder name
     *
     * @var string
     */
    public $cardHolderName = '';

    /**
     * Nexio Constructor.
     */
    public function __construct()
    {
        $this->init_plugin_settings();
        $this->init_plugin_hooks();
    }

    /**
     * Plugin configuration
     *
     */
    protected function init_plugin_settings()
    {
        $this->id = 'nexio';
        $this->method_title = __('Nexio', 'cms-gateway-nexio');

        $this->supports = array(
            'products',
            'refunds',
            'subscriptions',
            'add_payment_method',
            'tokenization',
            'subscription_cancellation',
            'subscription_suspension',
            'multiple_subscriptions',
            'subscription_reactivation',
            'subscription_amount_changes',
            'subscription_date_changes',
            'subscription_suspension',
            'subscription_payment_method_change_customer',
            'subscription_payment_method_change_admin',
            'change_payment_method'
        );

        $this->has_fields = true;
        $this->method_description = "Nexio works by adding payment fields on the checkout and then sending the details to Nexio for verification. <a href='https://nexiopay.com/contact/' target='_blank'>Contact Nexio</a> for an account.</a>.<br> Additional features such Fraud Check and Account Updater must be firstly enabled on the <strong>Nexio merchant settings</strong>.";

        $this->init_form_fields();
        $this->init_settings();

        $this->developmentMode = $this->get_option_boolean('developmentMode');

        if ($this->developmentMode) {
            $this->api_url = 'https://api.nexiopaydev.com/pay/';
        }
    }

    /**
     * Hooks and filters
     *
     */
    public function init_plugin_hooks()
    {
        // Hooks.
        add_action('woocommerce_scheduled_subscription_payment', array($this, 'nexio_renewal'));
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'nexio_process_admin_options'));
        add_action('woocommerce_api_' . strtolower(get_class($this)), array($this, 'nexio_after_tokenization'));
        add_action('woocommerce_api_' . strtolower(get_class($this) . 'threeds'), array($this, 'nexio_after_three_ds'));
        add_action('woocommerce_api_' . strtolower(get_class($this) . 'selectedpm'), array($this, 'nexio_before_tokenization'));
        add_action('woocommerce_available_payment_gateways', array($this, 'nexio_available_payment_gateways'));
        //filters.
        add_filter('woocommerce_order_button_html', array($this, 'nexio_place_order'), PHP_INT_MAX, -1);
        add_filter('woocommerce_account_menu_items', array($this, 'nexio_payment_methods_endpoint'), 40);
        // load css
        wp_register_style('nexio_css', plugins_url('assets/css/nexio.css', __FILE__), array());
    }

    public function nexio_available_payment_gateways($available_gateways)
    {
        if (is_admin()) {
            return $available_gateways;
        }

        if (is_wc_endpoint_url('payment-methods') || is_wc_endpoint_url('add-payment-method')) {
            $userCreditCardTokens = WC_Payment_Tokens::get_customer_tokens(get_current_user_id());
            if (!empty($userCreditCardTokens) && count($userCreditCardTokens) >= CMS_NEXIO_MAX_PAYMENT_METHODS) {
                unset($available_gateways['nexio']);
                echo '<p>You have reached the permitted amount of credit cards on your account</p>';
            }
        }
        return $available_gateways;
    }

    public function nexio_process_admin_options()
    {
        $before = md5(serialize($this->settings));
        $this->process_admin_options();
        $after = md5(serialize($this->settings));
        if ($before != $after) {
            unset($_SESSION['requestSent']);
        }
    }

    // Add payment methods tabs in my account page.
    public function nexio_payment_methods_endpoint($menu_links)
    {
        $menu_links = array_slice($menu_links, 0, 5, true)
            + array('payment-methods' => 'Payment methods')
            + array_slice($menu_links, 5, null, true);
        return $menu_links;
    }

    /**
     * customize place order button in checkout page.
     *
     * @since 0.0.10
     */
    public function nexio_place_order()
    {
        $order_button_text = __('Continue to payment', 'cms-gateway-nexio');
        $debugTxt = '';
        if ($this->developmentMode) {
            $debugTxt = ' >>>NEXIO<<<';
        }
        return '
            <input type="button" class="button alt nexio-pay-submit show" id="nexio-pay-submit" style="visibility: hidden;" value="' . esc_attr($order_button_text) . $debugTxt . '" data-value="' . esc_attr($order_button_text) . '" />
            <input type="submit" class="button alt nexio-pay-submit nexio-hidden" id="wordpress-custom-pay-submit" name="woocommerce_checkout_place_order" id="place_order" value="' . esc_attr($order_button_text) . '" data-value="' . esc_attr($order_button_text) . '" />
        ';
    }

    /**
     * payment_fields function provided by woocommerce, called when the credit card section of the checkout page loads.
     *
     * @return null
     * @version 1.0.0
     * @since 0.0.1
     */
    public function payment_fields()
    {
        require_once(dirname(__FILE__) . '/nexio-utils.php');
        $pageUrl = basename($_SERVER['REQUEST_URI']);
        $sanitizedPageUrl = sanitize_current_url($_SERVER['REQUEST_URI']);

        if ($pageUrl === 'add-payment-method' || $sanitizedPageUrl === 'order-pay') {
            echo $this->nexio_get_tokenize_iFrame();
        } elseif (( strpos($pageUrl, 'checkout') !== false || strpos($pageUrl, 'payment_fail') !== false ) && ! isset($_REQUEST['wfacp_is_checkout_override'])) {
            $existingCreditCardToken = WC_Payment_Tokens::get_customer_default_token(get_current_user_id());
            $userCreditCardTokens = WC_Payment_Tokens::get_customer_tokens(get_current_user_id());
            $userCreditCardTokens = $this->nexio_sanitize_user_tokens($userCreditCardTokens);
            // breaking up loading javascript and returning iFrame fixes issues with iframe loading twice this is super Hacky and should be refactored
            echo $this->loadNexioJS($userCreditCardTokens);
        } elseif (strpos($pageUrl, '?wc-ajax=update_order_review') !== false) {
            $existingCreditCardToken = WC_Payment_Tokens::get_customer_default_token(get_current_user_id());
            if ($existingCreditCardToken) {
                echo $this->loadNexioJS($existingCreditCardToken);
            }
            echo $this->nexio_get_iframe();
        }
    }

    public function nexio_sanitize_user_tokens($userCreditCardTokens)
    {
        if (isset($userCreditCardTokens)) {
            $sanitizedUserTokens = array();
            foreach ($userCreditCardTokens as $creditCardToken) {
                $sanitizedToken = array();
                $rawData = $creditCardToken->get_data();

                $sanitizedToken['data'] = array
                (
                'id'      => $rawData['id'],
                'gateway_id'    => $rawData['gateway_id'],
                'token'         => $rawData['token'],
                'is_default'    => $rawData['is_default'],
                'last4'         => $rawData['last4'],
                'expiry_month'  => $rawData['expiry_month'],
                'expiry_year'  => $rawData['expiry_year'],
                'card_type'     => $rawData['card_type'],
                );

                $sanitizedUserTokens[] = $sanitizedToken;
            }
            return json_encode($sanitizedUserTokens);
        }
    }

    /**
     * Initialise Gateway Settings Form Fields
     */
    public function init_form_fields()
    {
        $this->form_fields = require(dirname(WC_NEXIO_PLUGIN_FILE) . '/nexio-settings.php');
    }

    /**
     * Generate the form of pre-order page.
     *
     * @since 0.0.1
     */
    public function nexio_get_iframe()
    {
        // Loop through every cart item so we can check their product type before loading the iFrame
        $flagSuscription = false;
        if (!empty(WC()->cart)) {
            foreach (WC()->cart->get_cart() as $cart_item => $values) {
                $_product = wc_get_product($values['data']->get_id());
                if ($_product->is_type('subscription')) {
                    $flagSuscription = true;
                }
            }
        }

        $otuResult = $this->nexio_get_one_time_use_token();
        $formClass = ($this->get_option_boolean('hidebilling') ? 'nexio-form-sm' : 'nexio-form');

        if (isset($otuResult['error'])) {
            //get one time token return error, need info user to try again.
            return '' . '<p id="tokenerror" class="woocommerce-error">Error establishing connection to payment provider: ' . $this->nexio_sanitize_gateway_response($otuResult['error']) . '</p>
			<a href="' . wc_get_checkout_url() . '"><input type="button" value="Back to Checkout"></a>';
        }

        $nexioIframeUrl = $this->nexio_create_iFrame_src($otuResult['token']);

        if (!empty($GLOBALS['is_IE'])) {
            return '' . '
            <div class="nexio-loader" id="nexio-loader"></div>
            <div class="nexio-loader-msg" id="nexio-loader-msg">Insecure Browser Detected</div>
            ';
        } else {
            if ($flagSuscription) {
                return '' . '
                    <div class="nexio-token-pg" id="nexio-token-pg"></div>
                    <div class="nexio-loader" id="nexio-loader"></div>
                    <div class="nexio-loader-msg" id="nexio-loader-msg">Making secure connection</div>
                    <div id="nexio-payment-form" class="' . $formClass . '">
                        <iframe type="iframe" class="nexio-iframe" id="nexio-iframe" src="' . $nexioIframeUrl . '"></iframe>
                    </div>
                    <div class="nexio-save-card-container">
                    <input class="nexio-rounded-checkbox nexio-hidden-element" type="checkbox" id="nexio-save-card-checkbox" name="nexio-save-card-checkbox" checked="true" disabled>
                    <label class="nexio-hidden-element" id="nexio-card-save-checkbox-label" for="nexio-save-card-checkbox">This card will be saved for your subscription purchase</label>
                </div>
                    ';
            } else {
                return '' . '
                    <div class="nexio-token-pg" id="nexio-token-pg" name="nexio-selection"></div>
                    <div class="nexio-loader" id="nexio-loader"></div>
                    <div class="nexio-loader-msg" id="nexio-loader-msg">Making secure connection</div>
                    <div id="nexio-payment-form" class="' . $formClass . '">
                        <iframe type="iframe" class="nexio-iframe" id="nexio-iframe" src="' . $nexioIframeUrl . '"></iframe>
                    </div>
                    <div class="nexio-save-card-container">
                    <input class="nexio-rounded-checkbox nexio-hidden-element" type="checkbox" id="nexio-save-card-checkbox" name="nexio-save-card-checkbox">
                    <label class="nexio-hidden-element" id="nexio-card-save-checkbox-label" for="nexio-save-card-checkbox">Save Card</label>
                </div>
                    ';
            }
        }
    }

    //Generate iFrame for checkout/other pages
    public function loadNexioJS($existingTokens)
    {
        if (!isset($existingTokens)) {
            $existingTokens = 'null';
        }

        $nexioJavascript = file_get_contents(dirname(WC_NEXIO_PLUGIN_FILE) . '/nexio.js');
        $authVal = $this->get_option('developmentBasicAuth');

        wc_enqueue_js('
            const userLoggedIn = "' . is_user_logged_in() . '";
            const postPaymentUrl = "' . $this->nexio_create_woo_commerce_api_url() . '";
            const postSelectionUrl = "' . $this->nexio_create_woo_commerce_api_url() . 'selectedpm";
            const returnUrl = "' . $this->get_return_url() . '";
            const domainUrl = "' . rtrim($this->api_url, '/\\') . '";
            const existingTokens = ' . $existingTokens . ';
            const basicAuth = "' . $authVal . '";
            const paymentMethodsEndpoint = "' . wc_get_endpoint_url('payment-methods') . '";
            const maxPaymentMethods = ' . CMS_NEXIO_MAX_PAYMENT_METHODS . ';
            ' . $nexioJavascript . '
        ');
        wp_enqueue_style('nexio_css');
    }

    // Generate the iFrame for Add Payment Methods page
    public function nexio_get_tokenize_iFrame()
    {
        $nexioJavascript = file_get_contents(dirname(WC_NEXIO_PLUGIN_FILE) . '/nexioPaymentMethodsOnly.js');
        $otuResult = $this->nexio_get_one_time_use_token();
        $nexioIframeUrl = $this->nexio_create_iFrame_src($otuResult['token']);

        $authVal = $this->get_option('developmentBasicAuth');
        $formClass = ($this->get_option_boolean('hidebilling') ? 'nexio-form-sm' : 'nexio-form');

        wc_enqueue_js('
            const otu = "' . $otuResult['token'] . '";
            const userLoggedIn = "' . is_user_logged_in() . '";
            const postPaymentUrl = "' . $this->nexio_create_woo_commerce_api_url() . '";
            const returnUrl = "' . $this->get_return_url() . '";
            const paymentMethodPage = "' . wc_get_endpoint_url('payment-methods') . '";
            const domainUrl = "' . rtrim($this->api_url, '/\\') . '";
            const basicAuth = "' . $authVal . '";
            const existingTokens = false;
            ' . $nexioJavascript . '
        ');

        wp_enqueue_style('nexio_css');
        if (!empty($GLOBALS['is_IE'])) {
            return '' . '
            <div class="nexio-loader" id="nexio-loader"></div>
            <div class="nexio-loader-msg" id="nexio-loader-msg">Insecure Browser Detected</div>
            ';
        } else {
            return '' . '
            <div class="nexio-token-pg" id="nexio-token-pg"></div>
            <div class="nexio-loader" id="nexio-loader"></div>
            <div class="nexio-loader-msg" id="nexio-loader-msg">Making secure connection</div>
            <div id="nexio-payment-form" class="' . $formClass . '">
                <iframe type="iframe" class="nexio-iframe" id="nexio-iframe" src="' . $nexioIframeUrl . '"></iframe>
            </div>
            <div>
        </div>
			';
        }
    }


    /**
     * Generate the json string for getting one time token to load tokenization iframe.
     *
     * @since 0.0.1
     */
    function nexio_build_otu_request_json()
    {
        $cssUrl = trim($this->get_option('css'));
        $customTextUrl = trim($this->get_option('customtext_url'));
        $requireCvv = $this->get_option_boolean('requirecvc');
        $hideBilling = $this->get_option_boolean('hidebilling');
        $hideCvv = $this->get_option_boolean('hidecvc');
        $tokenWebhookUrl = $this->get_option('tokenWebhookUrl');
        $tokenFailWebhookUrl = $this->get_option('tokenFailWebhookUrl');
        $canAccountUpdater = $this->get_option_boolean('accountUpdater');

        $pluginFolder = basename(dirname(WC_NEXIO_PLUGIN_FILE));

        $uiOptions = array(
            'css' => (!empty($cssUrl) ? $cssUrl : content_url() . "/plugins/{$pluginFolder}/assets/css/nexioDefault.css"),
            'hideCvc' => $hideCvv,
            'customTextUrl' => (!empty($customTextUrl) ? $customTextUrl : ''),
            'requireCvc' => $requireCvv,
            'hideBilling' => $hideBilling,
            'displaySubmitButton' => !empty($GLOBALS['is_IE']),
            'customTextUrl' => (!empty($customTextUrl) ? $customTextUrl : ''),
        );

        $processingOptions = array(
            'webhookUrl' => stripslashes($tokenWebhookUrl),
            'webhookFailUrl' => stripslashes($tokenFailWebhookUrl),
        );

        if (is_user_logged_in()) {
            $userData = get_userdata(get_current_user_id());
            $customer = array(
                'firstName' => $userData->first_name,
                'lastName' => $userData->last_name,
                'email' => $userData->user_email,
                'customerRef' => get_current_user_id()
            );

            $request = array(
                'shouldUpdateCard' => $canAccountUpdater,
                'uiOptions' => $uiOptions,
                'processingOptions' => $processingOptions,
                'customer' => $customer
            );
        } else {
            $request = array(
                'uiOptions' => $uiOptions,
                'processingOptions' => $processingOptions
            );
        }
        return json_encode($request);
    }

    /**
     * creates a api url that can be called from an external page using the nexio_after_tokenization hook
     *
     * @return string
     * @version 1.0.0
     * @since 0.0.1
     */
    public function nexio_create_woo_commerce_api_url()
    {
        $apiURL = get_site_url(null, null, 'https') . '/?wc-api=' . strtolower(get_class($this));

        if (!empty($_ENV["RUN_ENVIRONMENT"]) && $_ENV["RUN_ENVIRONMENT"] === 'local') {
            $apiURL = str_replace("https", "http", $apiURL);
        }

        return $apiURL;
    }

    /**
     * creates a api url to pass to the nexio customerRedirectUrl
     *
     * @param string $orderNumber
     * @return string
     */
    public function nexio_customer_redirect_url($orderNumber)
    {
        $secretKey = $this->get_option('secret');
        $hid = hash_hmac('sha256', $orderNumber, $secretKey);

        $baseUrl = get_site_url(null, null, 'https');

        //local testing
        if ($this->developmentMode) {
            $newBase = str_replace("localhost", "127.0.0.1", $baseUrl);
            return $newBase . '/?wc-api=nexiothreeds&hid=' . $hid;
        } else {
            return $baseUrl . '/?wc-api=nexiothreeds&hid=' . $hid;
        }
    }

    /**
     * creates a api to be called from 3DS page nexio_after_three_ds hook
     *
     */
    public function nexio_after_three_ds()
    {
        $id = $_GET["id"];
        $hid = $_GET["hid"];
        $order_id = $_GET["orderNumber"];

        $secretKey = $this->get_option('secret');
        $key = hash_hmac('sha256', $order_id, $secretKey);

        if (($key !== $hid)) {
            $checkoutPage = wc_get_checkout_url();
            wp_redirect(add_query_arg('payment_error', "payment_fail", $checkoutPage));
        } elseif (!isset($id)) {
            $checkoutPage = wc_get_checkout_url();
            wp_redirect(add_query_arg('payment_error', "payment_fail", $checkoutPage));
        } else {
            $order = wc_get_order($order_id);
            $order->update_status('processing');
            wp_redirect($this->get_return_url($order));
        }
    }

    /**
     * Get one time token for fetch iFrame.
     *
     * @since 0.0.1
     */
    public function nexio_get_one_time_use_token()
    {
        try {
            $data = $this->nexio_build_otu_request_json();

            $ch = curl_init($this->api_url . 'v3/token');
            // try to allow self ssl
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "Authorization: {$this->createBasicAuth()}",
                "Content-Type: application/json",
                "Content-Length: " . strlen($data)
            ));
            $result = curl_exec($ch);
            $error = curl_error($ch);
            curl_close($ch);

            if ($error) {
                return ['error' => $error];
            } else {
                $decodedResult = json_decode($result);
                $onetimeUseToken = $decodedResult->token;

                if (empty($onetimeUseToken)) {
                    return ['error' => $decodedResult->error ? $decodedResult->error : $result ];
                }

                return ['token' => $onetimeUseToken];
            }
        } catch (Exception $e) {
            error_log("Get One Time Token:" . $e->getMessage(), 0);

            return ['error' => $e->getMessage()];
        }
    }

    /**
     * Get iFrame src url.
     *
     * @param string $oneTimeUseToken a one time use token string
     * @return string
     * @since 0.0.1
     */
    public function nexio_create_iFrame_src($oneTimeUseToken)
    {
        return $this->api_url . "v3/saveCard?token=" . $oneTimeUseToken;
    }

    //Setting default token before tokenization is complete
    public function nexio_before_tokenization()
    {
        $data = file_get_contents('php://input');
        $arrayData = json_decode($data);
        if (is_user_logged_in() && $arrayData->event === 'cardSelected') {
            $newDefaultToken = WC_Payment_Tokens::get($arrayData->customerSelectedTokenId);
            WC_Payment_Tokens::set_users_default(get_current_user_id(), $newDefaultToken->get_id());
        } else {
            return;
        }
    }

    /**
     * Handles the return from call from the html page after tokenization. called by woocommerce_api_ Hookook
     *
     * @since 0.0.1
     */
    public function nexio_after_tokenization()
    {
        //fetch selected card
        $data = file_get_contents('php://input');
        $arrayData = json_decode($data);

        if (isset($arrayData->data->card->cardHolderName)) {
            $this->cardHolderName = $arrayData->data->card->cardHolderName;
        }

        if (is_user_logged_in() && $arrayData->event === 'cardSaved') {
            $ccToken = $arrayData->data->token->token;
            WC()->session->set('nexio_order_token', $ccToken);
        }

        if (is_user_logged_in() && $arrayData->event !== 'cardSelected') {
            $ccToken = $arrayData->data->token->token;
        } elseif (!is_user_logged_in() && $arrayData->event === 'cardSaved') {
            $ccToken = $arrayData->data->token->token;
            $this->eventType = 'cardSaved';
        } elseif (is_user_logged_in() && $arrayData->event === "cardSaved" && !$arrayData->customerRequestsCardSave) {
            //The user is logged in and didn't requested to save a card.
            WC()->session->set('nexio_order_token', $ccToken);
        }

        $userID = get_current_user_id();
        $tokens = WC_Payment_Tokens::get_customer_tokens(get_current_user_id());

        if (($userID !== 0) && (count($tokens) < 10)) {
            $lastFour = $arrayData->data->token->lastFour;
            $cardType = $arrayData->data->token->cardType;
            $expYear = $arrayData->data->card->expirationYear;
            $expMonth = $arrayData->data->card->expirationMonth;

            $token = new WC_Payment_Token_CC();
            $token->set_token($ccToken);
            $token->set_gateway_id("Nexio");
            $token->set_last4("$lastFour");
            $token->set_expiry_year($expYear);
            $token->set_expiry_month($expMonth);
            $token->set_card_type($cardType);
            $token->set_user_id($userID);

            if ($arrayData->customerRequestsCardSave) {
                // Save the new token to the database if the user wants to do it
                $token->save();
                WC_Payment_Tokens::set_users_default($userID, $token->get_id());
            } else {
                    //use the session token if the user does not want to save the card
                    WC()->session->set('nexio_order_token', $ccToken);
            }
        } else {
            //The user has more than 10 tokens saved, so use it on the session only.
            WC()->session->set('nexio_order_token', $ccToken);
        }
    }

    public function nexio_process_payment($order, $cart, $voidTransaction)
    {
        require_once(dirname(__FILE__) . '/nexio-utils.php');

        $sendCountryAsTag = $this->get_option_boolean('sendCountryAsTag');

        try {
            $creditCardToken = null;
            if (is_user_logged_in() && empty(WC()->session->get('nexio_order_token'))) {
                $wooCommerceTokenObj = WC_Payment_Tokens::get_customer_default_token(get_current_user_id());
            }

            if (!empty($wooCommerceTokenObj) && $wooCommerceTokenObj->get_token() === WC()->session->get('nexio_order_token')) {
                $creditCardToken = $wooCommerceTokenObj->get_token();
            } else {
                //if the session token and the default token are different, try to use the session one instead of the default
                if (!empty(WC()->session->get('nexio_order_token'))) {
                    $creditCardToken = WC()->session->get('nexio_order_token');
                } elseif (is_user_logged_in() && !$arrayData->customerRequestsCardSave === true && !$arrayData->event) {
                    $wooCommerceTokenObj = WC_Payment_Tokens::get_customer_default_token(get_current_user_id());
                    if (!!!$wooCommerceTokenObj) {
                        throw new ErrorException("You must select one payment method. Please reload your cart.");
                    } else {
                        $creditCardToken = $wooCommerceTokenObj->get_token();
                    }
                } else {
                    $creditCardToken = WC()->session->get('nexio_order_token');
                }
                if (empty($creditCardToken)) {
                    throw new ErrorException("You session expired please reload your cart.");
                }
            }
            $data = $this->processPaymentPostBody($order, $cart, $creditCardToken);

            $ch = curl_init($this->api_url . 'v3/process');
            // try to allow self ssl
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "X-NEXIO-REQUEST-SOURCE: Woocommerce#" . $this->version,
                "Authorization: {$this->createBasicAuth()}",
                "Content-Type: application/json",
                "Content-Length: " . strlen($data)
            ));
            $result = curl_exec($ch);
            $error = curl_error($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            $result = json_decode($result, true);
            $gatewayStatus = getStatusFromApiResponse($result);

            $order_status = $order->get_status();
            if ($voidTransaction === true) {
                $this->void_purchase($result['id']);
            }
            if (($httpcode === 200 && empty($result['redirectUrl']))) {
                $order->update_status($gatewayStatus);
                WC()->session->__unset('nexio_order_token');

                return array(
                    'result' => 'success',
                    'redirect' => $this->get_return_url($order)
                );
            } elseif (isset($result['redirectUrl'])) {
                return array(
                    'result' => 'success',
                    'redirect' => $result['redirectUrl']
                );
            } else {
                $gateWayMessage = nexio_sanitize_gateway_message($result["message"], $this->sendCountryAsTag);
                $msg = 'HTTP Code: ' . $httpcode . ' Nexio Error: ' . $error . ' Gateway Error: ' . $result["error"] . ' Gateway Message: ' . $gateWayMessage;
                $msg = $this->developmentMode ? $msg : $gateWayMessage;
                $msg = $httpcode === 0 ? "The transaction has lost communication, please check your internet connection and try again" : $msg;
                WC()->session->__unset('nexio_order_token');
                throw new ErrorException($msg);
            }
        } catch (Exception $e) {
            error_log("Processing payment:" . $e->getMessage(), 0);
            $order->update_status('failed');
            wc_add_notice(__('Payment error: ', 'woothemes') . "Transaction Declined: " . nexio_sanitize_gateway_response($e->getMessage(), $this->developmentMode), 'error');

            return;
        }
    }

    public function getStatusFromApiResponse($result)
    {
        $transactionStatus = "";
        if (!empty($result['error'])) {
            $transactionStatus = $result['gatewayResponse']['status'];
        } else {
            if ($result['transactionStatus'] === 'pending' || $result['transactionStatus'] === 'settled') {
                $transactionStatus = "processing";
            } else {
                $transactionStatus = $result['transactionStatus'];
            }
        }
        return $transactionStatus;
    }

    public function nexio_renewal($subscription_Id)
    {
        $subscription = wcs_get_subscription($subscription_Id);
        $relatedOrderIds = $subscription->get_related_orders('ids');
        $user = $subscription->get_user_id();
        $maxOrderId = max($relatedOrderIds);
        $recentOrder = wc_get_order($maxOrderId);
        $token = WC_Payment_Tokens::get_customer_default_token($user);

        return $this->nexio_process_renewal($recentOrder, $token);
    }

    public function nexio_process_renewal($order, $token)
    {
        try {
            $tokenArray = json_decode($token, true);
            $creditCardToken = array(
                'token' => $tokenArray['token'],
                'last4' => $tokenArray['last4'],
                'expiry_year' => $tokenArray['expiry_year'],
                'expiry_month' => $tokenArray['expiry_month'],
                'card_type' => $tokenArray['card_type'],
            );
            $cart = array();

            $data = $this->processPaymentPostBody($order, $cart, $creditCardToken);

            $ch = curl_init($this->api_url . 'v3/process');
            // try to allow self ssl
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "X-NEXIO-REQUEST-SOURCE: Woocommerce#" . $this->version,
                "Authorization: {$this->createBasicAuth()}",
                "Content-Type: application/json",
                "Content-Length: " . strlen($data)
            ));
            $result = curl_exec($ch);
            $error = curl_error($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            $result = json_decode($result, true);
            $order_status = $order->get_status();

            if (($httpcode === 200 && empty($result['redirectUrl']))) {
                $order->update_status($order_status);
                if ($order_status === 'pending') {
                    $order->update_status('processing');
                }

                return array(
                    'result' => 'success',
                    'redirect' => $this->get_return_url($order)
                );
            } elseif (isset($result['redirectUrl'])) {
                throw new ErrorException('Card Holder approval required (3DS)');
            } else {
                $msg = 'HTTP Code: ' . $httpcode . ' Nexio Error: ' . $error . ' Gateway Error: ' . $result["error"] . ' Gateway Message: ' . $result["message"];
                $msg = $this->developmentMode ? $msg : $result['message'];
                $msg = $httpcode === 0 ? "The transaction has lost communication, please check your internet connection and try again" : $msg;
                throw new ErrorException($msg);
            }
        } catch (Exception $e) {
            error_log("Processing payment:" . $e->getMessage(), 0);

            $order->update_status('failed');

            wcs_add_admin_notice($e->getMessage(), 'error');
        }
    }

    function processPaymentPostBody($order, $cart, $CCToken)
    {
        $orderNumber = $order->get_order_number();
        $customer = array(
            'orderNumber' => $orderNumber,
            'firstName' => $order->get_billing_first_name(),
            'lastName' => $order->get_billing_last_name(),
            'billToAddressOne' => $order->get_billing_address_1(),
            'billToAddressTwo' => $order->get_billing_address_2(),
            'billToCity' => $order->get_billing_city(),
            'billToState' => $order->get_billing_state(),
            'billToPostal' => $order->get_billing_postcode(),
            'billToCountry' => $order->get_billing_country(),
            'email' => $order->get_billing_email(),
            'phone' => $order->get_billing_phone(),
            'shipToAddressOne' => $order->get_shipping_address_1(),
            'shipToAddressTwo' => $order->get_shipping_address_2(),
            'shipToCity' => $order->get_shipping_city(),
            'shipToState' => $order->get_shipping_state(),
            'shipToPostalCode' => $order->get_shipping_postcode(),
            'shipToCountry' => $order->get_shipping_country()
        );

        $nexioCartItems = array();

        if (!empty(WC()->cart)) {
            foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
                $nexioCartItem = array(
                    "item" => $cart_item['data']->get_title(),
                    "quantity" => $cart_item['quantity'],
                    "price" => $cart_item['data']->get_price(),
                    "type" => 'sale',
                );
                array_push($nexioCartItems, $nexioCartItem);
            }

            $cart = array(
                'items' => $nexioCartItems
            );
        }

        $data = array(
            'paymentMethod' => 'creditCard',
            'allowedCardTypes' => ['visa', 'mastercard', 'discover', 'amex'],
            'amount' => $order->get_total(),
            'currency' => get_woocommerce_currency(),
            'customer' => $customer,
            'cart' => $cart
        );
        //For subscriptions to void zero amount error, send a charge with isAuthOnly.
        if (strpos($_SERVER['REQUEST_URI'], 'order-pay') !== false) {
            $data['amount'] = 0.01;
            $request['isAuthOnly'] = true;
        }

        if (is_array($CCToken)) {
            $tokenex = array(
                'token' => $CCToken['token'],
                'last4' => $CCToken['last4'],
                'expiry_year' => $CCToken['expiry_year'],
                'expiry_month' => $CCToken['expiry_month'],
                'card_type' => $CCToken['card_type'],
            );
        } else {
            $tokenex = array(
                'token' => $CCToken
            );
        }

        $customerRedirectUrl = $this->nexio_customer_redirect_url($orderNumber);
        $canFraud = $this->get_option_boolean('fraud');
        $canTHreeDS = $this->get_option_boolean('check3ds');
        $sendCountryAsTag = $this->get_option_boolean('sendCountryAsTag');
        $canAuthonly = $this->get_option_boolean('authonly');
        $webhookUrl = $this->get_option('webhookUrl');
        $failWebhookUrl = $this->get_option('failWebhookUrl');

        $processingOptions = array(
            'checkFraud' => $canFraud,
            'check3ds' => $canTHreeDS,
            'customerRedirectUrl' => stripslashes($customerRedirectUrl),
            'webhookUrl' => stripslashes($webhookUrl),
            'webhookFailUrl' => stripslashes($failWebhookUrl),
        );

        if ($sendCountryAsTag) {
            $processingOptions['paymentOptionTag'] = $order->get_billing_country();
        }

        $customTextUrl = trim($this->get_option('customtext_url'));

        if (!empty($customTextUrl)) {
            $uiOptions['customTextUrl'] = $customTextUrl;
        }

        $this->cardHolderName = $this->cardHolderName !== '' ? $this->cardHolderName : $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();

        $card = array(
            'cardHolderName' => $this->cardHolderName
        );

        $request = array(
            'tokenex' => $tokenex,
            'data' => $data,
            'processingOptions' => $processingOptions,
            'uiOptions' => $uiOptions,
            'card' => $card,
            'isAuthOnly' => $canAuthonly
        );

        return json_encode($request, JSON_UNESCAPED_SLASHES);
    }

    public function process_payment($order_id, $retry = true, $force_save_source = false, $previous_error = false)
    {

        if (strpos($_SERVER['REQUEST_URI'], 'order-pay') !== false) {
            $order = wc_get_order($order_id);
            $cart = WC()->cart->get_cart();
            return $this->nexio_process_payment($order, $cart, true);
        } else {
            $order = wc_get_order($order_id);
            $cart = WC()->cart->get_cart();
            return $this->nexio_process_payment($order, $cart, false);
        }
    }

    public function add_payment_method()
    {
        wp_redirect(wc_get_endpoint_url('payment-methods'));
    }

    public function nexio_sanitize_gateway_response($response)
    {
        if (!empty($response)) {
            $filteredResponseMessage = nexio_filter_response_list($response);
            $message = $this->developmentMode ? $response : $filteredResponseMessage;
            return $message;
        }
    }

    public function void_purchase($id)
    {
        $ch = curl_init($this->api_url . 'v3/void');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers = array(
            "X-NEXIO-REQUEST-SOURCE: Woocommerce#" . $this->version,
            'Authorization: ' . $this->createBasicAuth(),
            'Content-Type: application/json'
        );
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $fields = json_encode(array('id' => $id));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        $result = curl_exec($ch);
        $error = curl_error($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        echo $httpcode;
        $result = json_decode($result, true);
        if ($result['transactionStatus'] !== 'voided') {
            error_log('Error: unable to void transaction with ID ' . $result['id'] . '-- ' . 'Message: ' . $result['message']);
        }
    }

    /**
     * Handles creating basic auth
     *
     * @return string
     */
    protected function createBasicAuth()
    {
        $username = $this->get_option('user_name');
        $password = $this->get_option('password');

        return 'Basic ' . base64_encode($username . ':' . $password);
    }

    /**
     * Get boolean equivalent of an option
     *
     * @return boolean
     */
    protected function get_option_boolean($field)
    {
        return $this->get_option($field) === 'yes';
    }
}
