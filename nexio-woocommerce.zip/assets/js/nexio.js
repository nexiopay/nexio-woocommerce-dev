/* global wc_nexio_params */

jQuery(function($) {
    'use strict';

    var tokenData = null;

    var wc_nexio_form = {
        init: function () {
            console.log('wc_nexio_params --->', wc_nexio_params);
            if (wc_nexio_params.is_pay_for_order_page === 'yes' || wc_nexio_params.is_change_payment_page === 'yes') {
                $(document.body).trigger( 'wc-credit-card-form-init' );
            }

            if ($('form.woocommerce-checkout').length) {
                this.form = $('form.woocommerce-checkout');
            }

            $('form.woocommerce-checkout').on('checkout_place_order_nexio', this.onSubmit);

            // pay order page
            if ($('form#order_review').length) {
                this.form = $('form#order_review');
            }

            // add payment method page
            if ($('form#add_payment_method').length) {
                this.form = $('form#add_payment_method');
            }

            $('form#order_review, form#add_payment_method').on('submit', this.onSubmit);

            $(window).on('message', this.handleNexioEvent);

            // Initially hide the nexio form if not selected
            if (wc_nexio_params.has_saved_cards 
                && ! $('#wc-nexio-payment-token-new').is(':checked')
                && wc_nexio_params.is_add_payment_page !== 'yes'
            ) {
                $('#wc-nexio-cc-form').hide();
            }

            $(document)
                .on('checkout_error', this.resetNexioForm);

            // Delay mounting the nexio form in checkout page to prevent
            // the form loading twice
            if (wc_nexio_params.is_checkout_page === 'yes') {
                if ($('#wc-nexio-iframe').length) {
                    return;
                }

                $(document.body).on('updated_checkout', function() {
                    wc_nexio_form.mountNexioForm();
                });
            } else {
                wc_nexio_form.mountNexioForm();
            }
        },

        mountNexioForm: function (formUrl = null) {
            if (formUrl) {
                $('#wc-nexio-iframe-wrapper').append(
                    $('<iframe type="iframe" />')
                        .addClass('nexio-iframe')
                        .attr('id', 'wc-nexio-iframe')
                        .attr('src', formUrl)
                );
            } else {
                if ($('#wc-nexio-iframe').length) {
                    return;
                }
    
                $('#wc-nexio-iframe-wrapper').append(
                    $('<iframe type="iframe" />')
                        .addClass('nexio-iframe')
                        .attr('id', 'wc-nexio-iframe')
                        .attr('src', wc_nexio_params.nexio_form_url)
                );
            }
        },

        hasToken: function () {
            return $('input.nexio-token').length > 0;
        },

        isNexioPayment: function () {
            return $('#payment_method_nexio').is(':checked');
        },

        isNexioSaveCardPayment: function () {
            return wc_nexio_form.isNexioPayment()
                && $('input[name="wc-nexio-payment-token"]').is(':checked')
                && $('input[name="wc-nexio-payment-token"]:checked').val() !== 'new';
        },

        onSubmit: function () {
            if (! wc_nexio_form.isNexioPayment()) {
                return true;
            }

            // If a token is in place, submit the form as usual.
            if (wc_nexio_form.isNexioSaveCardPayment() || wc_nexio_form.hasToken()) {
                return true;
            }

            wc_nexio_form.block();
    
            // submit the form as usual
            if ($('iframe#wc-nexio-iframe').length) {
                $('iframe#wc-nexio-iframe')[0].contentWindow.postMessage('posted', wc_nexio_params.nexio_api_url);
            } else {
                wc_nexio_form.unblock();
            }

            return false;
        },

        resetNexioForm: function () {
            wc_nexio_form.unblock();
            $('.nexio-token').remove();
            $('.nexio-loader-element').show();
            $('#wc-nexio-iframe').remove();
            $('#wc-nexio-iframe-wrapper').hide()

            if ($('#wc-nexio-savecard-container').length) {
                $('#wc-nexio-savecard-container').hide();
            }

            // Generate new payment form
            $.ajax({
                url: wc_nexio_params.ajax_create_payment_url,
                type: 'POST',
                success: function (response) {
                    wc_nexio_form.mountNexioForm(response.data.formUrl);
                }
            });
        },

        block: function() {
            wc_nexio_form.form.block({
                message: null,
                overlayCSS: {
                    background: '#fff',
                    opacity: 0.6
                }
            });
        },

        unblock: function() {
            wc_nexio_form.form && wc_nexio_form.form.unblock();
        },

        handleNexioEvent: function (e) {
            const event = e.originalEvent;
            const message = event.data;

            if (event.origin !== wc_nexio_params.nexio_api_url) {
                return;
            }

            switch (message.event) {
                case 'cardSaved':
                    wc_nexio_form.handleAfterTokenization(message.data);
                    break;
                case 'loaded':
                    wc_nexio_form.formLoaded();
                    break;
                case 'formValidations':
                    ! message.data.isFormValid && wc_nexio_form.unblock();
                    break;
            }

            console.log('Nexio Event -->'+message.event, message.data);
        },

        formLoaded: function () {
            if ($('.nexio-loader-element').length) {
                $('.nexio-loader-element').hide();
            }
            
            $('#wc-nexio-iframe-wrapper').show();

            if ($('#wc-nexio-savecard-container').length) {
                $('#wc-nexio-savecard-container').show();
            }
        },

        handleAfterTokenization: function (tokenData) {
            $('.nexio-token').remove();

            wc_nexio_form.form.append(
                $('<input type="hidden" />')
                    .addClass('nexio-token')
                    .attr('name', 'nexio_token')
                    .val(JSON.stringify(tokenData))
            );
    
            wc_nexio_form.form.trigger('submit');
        }
    };

    wc_nexio_form.init();
});

