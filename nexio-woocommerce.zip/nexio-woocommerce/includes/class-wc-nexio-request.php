<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class WC_Nexio_Request {

    /**
     * Creates an api url to pass to the nexio customerRedirectUrl
     *
     * @param $order_num
     * @param $secret
     * @return string
     */
    public static function nexio_customer_redirect_url($order_num, $secret) {
        return site_url() . '/?wc-api=nexiothreeds&hid=' . hash_hmac('sha256', $order_num, $secret);
    }

    /**
     * Generate Nexio cart data.
     *
     * @return array
     */
    public static function generate_nexio_cart_data() {
        $cart_items = [];
    
        if (isset(WC()->cart)) {
            foreach (WC()->cart->get_cart() as $item) {
                $cart_items[] = [
                    'item' => $item['data']->get_title(),
                    'quantity' => $item['quantity'],
                    'price' => $item['data']->get_price(),
                    'type' => 'sale',
                ];
            }
        }

        return $cart_items;
    }

    /**
     * Retrieve token from request.
     *
     * @return array
     */
    public static function get_token_from_request() {
        if (is_user_logged_in()
            && isset($_POST['wc-nexio-payment-token'])
            && $_POST['wc-nexio-payment-token'] !== 'new'
        ) {
            return self::get_existing_token_from_request();
        } else {
            return self::get_nexio_token_from_request();
        }
    }

    /**
     * Retrieve Nexio token from request.
     *
     * @return array
     */
    public static function get_existing_token_from_request() {
        $customer_id = get_current_user_id();
        $token_id = $_POST['wc-nexio-payment-token'];
        $tokens = WC_Payment_Tokens::get_customer_tokens($customer_id, 'nexio');

        if (! isset($tokens[$token_id])) {
            return null;
        }

        $token = (object) $tokens[$token_id]->get_data();

        return [
            'token' => $token->token,
            'last4' => $token->last4,
            'expiry_year' => $token->expiry_year,
            'expiry_month' => $token->expiry_month,
            'card_type' => $token->card_type
        ];
    }
    /**
     * Retrieve Nexio token from request.
     *
     * @return array
     */
    public static function get_nexio_token_from_request() {
        if (! isset($_POST['nexio_token']) || empty($_POST['nexio_token'])) {
            return null;
        }

        $nexio_token = json_decode(wp_unslash($_POST['nexio_token']), false);

        return [
            'token' => $nexio_token->token->token,
            'last4' => $nexio_token->token->lastFour,
            'expiry_year' => $nexio_token->card->expirationYear,
            'expiry_month' => $nexio_token->card->expirationMonth,
            'card_type' => $nexio_token->card->cardType
        ];
    }

    /**
     * Generate Nexio payment request data.
     *
     * @param WC_Order $order
     * @param array $nexio_token|null
     * @return object
     */
    public static function nexio_payment($order, $nexio_token = null) {
        $settings = self::get_settings();
        $payment_url = self::get_api_base_url() . '/pay/v3/process';

        if (! $nexio_token) {
            $nexio_token = self::get_token_from_request();
        }

        $processing_options = [
            'checkFraud' => isset($settings['fraud']) && $settings['fraud'] === 'yes',
            'check3ds' => isset($settings['check3ds']) && $settings['check3ds'] === 'yes',
            'customerRedirectUrl' => self::nexio_customer_redirect_url($order->get_order_number(), $settings['secret']),
            'webhookUrl' => isset($settings['webhookUrl']) ? $settings['webhookUrl'] : '',
            'webhookFailUrl' => isset($settings['failWebhookUrl']) ? $settings['failWebhookUrl'] : '',
        ];

        if (isset($settings['sendCountryAsTag']) && $settings['sendCountryAsTag'] === 'yes') {
            $processing_options['paymentOptionTag'] = $order->get_billing_country();
        }

        $ui_options = [];
        if (isset($settings['customtext_url']) && ! empty($settings['customtext_url'])) {
            $ui_options['customTextUrl'] = $settings['customtext_url'];
        }

        $request = [
            'data' => [
                'paymentMethod' => 'creditCard',
                'allowedCardTypes' => ['visa', 'mastercard', 'discover', 'amex'],
                'amount' => $order->get_total(),
                'currency' => get_woocommerce_currency(),
                'customer' => [
                    'orderNumber' => $order->get_order_number(),
                    'firstName' => $order->get_billing_first_name(),
                    'lastName' => $order->get_billing_last_name(),
                    'billToAddressOne' => $order->get_billing_address_1(),
                    'billToAddressTwo' => $order->get_billing_address_2(),
                    'billToCity' => $order->get_billing_city(),
                    'billToState' => $order->get_billing_state(),
                    'billToPostal' => $order->get_billing_postcode(),
                    'billToCountry' => $order->get_billing_country(),
                    'email' => $order->get_billing_email(),
                    'phone' => $order->get_billing_phone(),
                    'shipToAddressOne' => $order->get_shipping_address_1(),
                    'shipToAddressTwo' => $order->get_shipping_address_2(),
                    'shipToCity' => $order->get_shipping_city(),
                    'shipToState' => $order->get_shipping_state(),
                    'shipToPostalCode' => $order->get_shipping_postcode(),
                    'shipToCountry' => $order->get_shipping_country()
                ],
                'cart' => self::generate_nexio_cart_data()
            ],
            'tokenex' => $nexio_token,
            'processingOptions' => $processing_options,
            'uiOptions' => $ui_options,
            'card' => [
                'cardHolderName' => trim("{$order->get_billing_first_name()} {$order->get_billing_last_name()}")
            ],
            'isAuthOnly' => isset($settings['authonly']) && $settings['authonly'] === 'yes'
        ];

        return self::request('POST', $payment_url, $request);
    }

    /**
     * Generate Nexio one-time-use token.
     *
     * @return object
     */
    public static function generate_otu_token() {
        $settings = self::get_settings();
        $otu_token_url = self::get_api_base_url() . '/pay/v3/token';

        $request = [
            'data' => [
                'currency' => get_woocommerce_currency()
            ],
            'uiOptions' => [
                'css' => !empty($settings['css']) ? $settings['css'] : plugins_url('assets/css/nexio.css', WC_NEXIO_MAIN_FILE),
                'customTextUrl' => !empty($settings['customtext_url']) ? $settings['customtext_url'] : '',
                'hideBilling' => isset($settings['hidebilling']) && $settings['hidebilling'] === 'yes',
                'hideCvc' => isset($settings['hidecvc']) && $settings['hidecvc'] === 'yes',
                'requireCvc' => isset($settings['requirecvc']) && $settings['requirecvc'] === 'yes'
            ]
        ];

        return self::request('POST', $otu_token_url, $request);
    }

    /**
     * Whoami function.
     *
     * @return object
     */
    public static function whoami() {
        $whoamiUrl = self::get_api_base_url() . '/user/v3/account/whoAmI';
        $whoamiResult = self::request('GET', $whoamiUrl);

        $merchantUrl = self::get_api_base_url() . '/merchant/v3';
        $merchantResult = self::request('GET', $merchantUrl);

        return (object) [
            'whoami' => $whoamiResult->data,
            'merchant' => $merchantResult->data,
        ];
    }

    /**
     * Nexio request
     *
     * @param string $method
     * @param string $url
     * @param array $data
     * @param array $headers
     * @return object
     */
    public static function request($method = '', $url = '', $data = [], $headers = []) {
        $curl = curl_init();

        $headers = array_merge([
            'X-NEXIO-REQUEST-SOURCE: Woocommerce#' . WC_NEXIO_VERSION,
            'Authorization: ' . self::create_basic_auth(),
        ], $headers);

        if (strtolower($method) === 'get') {
            $data = http_build_query($data);
        } else {
            $data = json_encode($data);
            $headers[] = 'Content-Type: application/json';
            $headers[] = 'Content-Length: ' . strlen($data);
        }

        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_HTTPHEADER => $headers
        ]);

        $result = curl_exec($curl);
        $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        if (curl_errno($curl)) {
            return (object) [
                'statusCode' => $statusCode,
                'error' => curl_error($curl),
                'errorCode' => 0,
                'data' => []
            ];
        }

        curl_close($curl);

        $decodedResult = json_decode($result, false);

        $response = [
            'statusCode' => $statusCode,
            'data' => $decodedResult
        ];

        if (!empty($decodedResult->error)) {
            $response['error'] = $decodedResult->message;
            $response['errorCode'] = $decodedResult->error;
        }

        return (object) $response;
    }

    /**
     * Retrieve nexio api base url
     *
     * @return string
     */
    public static function get_api_base_url() {
        $testmode = self::get_settings('testmode');

        if ($testmode === 'yes') {
            return 'https://api.nexiopaysandbox.com';
        }

        return 'https://api.nexiopay.com';
    }

    /**
     * Retrieve nexio settings (woocommerce_nexio_settings)
     *
     * @param string $key
     * @return string|array
     */
    public static function get_settings($key = null) {
        $settings = get_option('woocommerce_nexio_settings');

        if (!$key) {
            return $settings;
        }

        return $settings[$key] ?? '';
    }

    /**
     * Creates basic auth key for nexio api request
     *
     * @return string
     */
    public static function create_basic_auth() {
        return 'Basic ' . base64_encode(self::get_settings('user_name') . ':' . self::get_settings('password'));
    }


    /**
     * Generate Nexio payment request data.
     *
     * @param $transaction_id
     * @param $amount
     * @return object
     */
    public static function nexio_refund($transaction_id, $amount) {
        $refund_url = self::get_api_base_url() . '/pay/v3/refund';

        $request = [
            'data' => [
                'amount' => $amount
            ],
            'id' => $transaction_id
        ];

        return self::request('POST', $refund_url, $request);
    }
}
