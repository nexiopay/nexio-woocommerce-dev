<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Gateway_Nexio class.
 *
 * @extends WC_Payment_Gateway
 */
class WC_Gateway_Nexio extends WC_Payment_Gateway_CC {
    /**
     * Is in test mode?
     *
     * @var bool
     */
    public $testmode;

    /**
     * Nexio Constructor.
     */
    public function __construct()
    {
        $this->id = 'nexio';
        $this->method_title = __('Nexio', 'cms-gateway-nexio');
        $this->method_description = "Nexio works by adding payment fields on the checkout and then sending the details to Nexio for verification. <a href='https://nexiopay.com/contact/' target='_blank'>Contact Nexio</a> for an account.</a>.<br> Additional features such Fraud Check and Account Updater must be firstly enabled on the <strong>Nexio merchant settings</strong>.";
        $this->has_fields = true;

        $this->supports = array(
            'products',
            'refunds',
            'add_payment_method',
            'tokenization',
        );

        // Load the form fields.
        $this->init_form_fields();

        // Load the settings.
        $this->init_settings();


        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->new_method_label = '+ Add Card';
        $this->testmode = $this->get_option('testmode') === 'yes';

        add_action('wp_enqueue_scripts', [$this, 'payment_scripts']);
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
        add_action('woocommerce_api_' . strtolower(get_class($this) . 'threeds'), array($this, 'nexio_after_three_ds'));
        add_filter('woocommerce_account_menu_items', array($this, 'nexio_payment_methods_endpoint'), 40);
        add_action('wc_ajax_wc_nexio_create_payment_form_url', [$this, 'create_payment_form_url']);
    }

    /**
     * Initialise Gateway Settings Form Fields
     */
    public function init_form_fields()
    {
        $this->form_fields = require dirname(__FILE__) . '/admin/nexio-settings.php';
    }

    /**
     * Payment_scripts function.
     *
     * Outputs scripts used for nexio payment
     */
    public function payment_scripts()
    {
        // We need javascript to process a token only on cart/checkout page
        if (
            !is_cart()
            && !is_checkout()
            && !isset($_GET['pay_for_order'])
            && !is_add_payment_method_page()
        ) {
            return;
        }

        // Check if Nexio is enabled
        if ($this->enabled === 'no') {
            return;
        }

        $username = $this->get_option('user_name');
        $password = $this->get_option('password');
        // Check if keys are set
        if (empty($username) || empty($password)) {
            return;
        }

        // Check if SSL is present and not in testmode
        if (!$this->testmode && !is_ssl()) {
            return;
        }

        $otu_token = WC_Nexio_Request::generate_otu_token();
        $nexio_form_url = WC_Nexio_Request::get_api_base_url() . '/pay/v3/saveCard?token=' . $otu_token->data->token;

        $js_file = defined('WC_NEXIO_DEBUG_MODE') && WC_NEXIO_DEBUG_MODE ? 'nexio.js' : 'nexio.min.js';

        wp_register_style('nexio_styles', plugins_url('assets/css/nexio.css', WC_NEXIO_MAIN_FILE ), [], WC_NEXIO_VERSION);
        wp_enqueue_style('nexio_styles');

        wp_register_script('woocommerce_nexio', plugins_url('/assets/js/' . $js_file, WC_NEXIO_MAIN_FILE), [ 'jquery-payment' ], WC_NEXIO_VERSION, true);
        wp_localize_script(
            'woocommerce_nexio',
            'wc_nexio_params',
            [
                'is_pay_for_order_page' => is_wc_endpoint_url('order-pay') ? 'yes' : 'no',
                'is_checkout_page' => (is_checkout() && empty($_GET['pay_for_order'])) ? 'yes' : 'no',
                'is_change_payment_page' => isset($_GET['change_payment_method']) ? 'yes' : 'no',
                'nexio_api_url' => WC_Nexio_Request::get_api_base_url(),
                'nexio_form_url' => $nexio_form_url,
                'has_saved_cards' => count($this->get_tokens()) > 0,
                'ajax_create_payment_url' => WC_AJAX::get_endpoint('wc_nexio_create_payment_form_url'),
                'order_id' => absint(get_query_var('order-pay')),
                'is_add_payment_page' => is_wc_endpoint_url('add-payment-method') ? 'yes' : 'no',
            ]
        );

        wp_enqueue_script('woocommerce_nexio');
    }

    /**
     * Create new nexio payment form url.
     *
     * @return json
     */
    public function create_payment_form_url()
    {
        $result = WC_Nexio_Request::generate_otu_token();

        if (! isset($result->data->token)) {
            wp_send_json_error([
                'error' => [
                    'message' => $result->error,
                ],
            ]);
        }
        
        wp_send_json_success([
            'token' => $result->data->token,
            'formUrl' => WC_Nexio_Request::get_api_base_url() . '/pay/v3/saveCard?token=' . $result->data->token
        ], 200);
    }

    /**
     * Check if the gateway is available for use.
     *
     * @return bool
     */
    public function is_nexio_gateway_available()
    {
        $is_available = $this->is_available();

        if (is_user_logged_in() && count($this->get_tokens()) >= WC_NEXIO_MAX_PAYMENT_METHODS) {
            $is_available = false;
        }

        return $is_available;
    }

    /**
     * Account Payment methods.
     *
     * @param array $menu_links
     * @return array
     */
    public function nexio_payment_methods_endpoint($menu_links)
    {
        return array_slice($menu_links, 0, 5, true)
            + array('payment-methods' => 'Payment methods')
            + array_slice($menu_links, 5, null, true);
    }

    /**
     * Outputs a checkbox for saving a new payment method to the database.
     *
     * @since 2.6.0
     */
    public function save_payment_method_checkbox()
    {
        $html = sprintf(
            '<div id="wc-%1$s-savecard-container" style="display:none">
                <p class="form-row woocommerce-SavedPaymentMethods-saveNew">
                    <input id="wc-%1$s-new-payment-method" name="wc-%1$s-new-payment-method" type="checkbox" value="true" style="width:auto;" />
                    <label for="wc-%1$s-new-payment-method" style="display:inline;">%2$s</label>
                </p>
            </div>',
            esc_attr($this->id),
            esc_html__('Save Card', 'woocommerce')
        );

        echo apply_filters('woocommerce_payment_gateway_save_new_payment_method_option_html', $html, $this); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    /**
     * Gets saved payment method HTML from a token.
     *
     * @since 2.6.0
     * @param  WC_Payment_Token $token Payment Token.
     * @return string Generated payment method HTML
     */
    public function get_saved_payment_method_option_html($token)
    {
        $html = sprintf(
            '<li class="woocommerce-SavedPaymentMethods-token nexio-card-item">
                <input id="wc-%1$s-payment-token-%2$s" type="radio" name="wc-%1$s-payment-token" value="%2$s" style="width:auto;" class="woocommerce-SavedPaymentMethods-tokenInput nexio-card-radio" %8$s />
                <div class="%1$s-cc-container">
                    <i class="%1$s-cc-%3$s"></i>
                    <div class="%1$s-exp-container">
                        <label class="%1$s-card-label" for="%1$s-card-%2$s">%4$s ending in %7$s  </label>
                        <label class="%1$s-expire-date">Exp %6$s / %5$s</label>
                    </div>
                </div>
            </li>',
            esc_attr($this->id),
            esc_attr($token->get_id()),
            esc_html($token->get_card_type()),
            esc_html(ucfirst($token->get_card_type())),
            esc_html($token->get_expiry_year()),
            esc_html($token->get_expiry_month()),
            esc_html($token->get_last4()),
            checked($token->is_default(), true, false)
        );

        return apply_filters('woocommerce_payment_gateway_get_saved_payment_method_option_html', $html, $token, $this);
    }

    /**
     * Payment form
     */
    public function payment_fields()
    {
        global $wp;
        $user                 = wp_get_current_user();
        $display_tokenization = $this->supports('tokenization') && is_checkout() && is_user_logged_in();
        $total                = WC()->cart->total;
        $user_email           = '';
        $description          = $this->get_description() ?? '';
        $firstname            = '';
        $lastname             = '';

        // If paying from order, we need to get total from order not cart.
        if (isset($_GET['pay_for_order']) && ! empty($_GET['key'])) {
            $order = wc_get_order(wc_clean($wp->query_vars['order-pay']));
            $total = $order->get_total();
            $user_email = $order->get_billing_email();
        } else {
            if ($user->ID) {
                $user_email = get_user_meta($user->ID, 'billing_email', true)
                    ?? $user->user_email;
            }
        }

        if (is_add_payment_method_page()) {
            $firstname = $user->user_firstname;
            $lastname  = $user->user_lastname;
        }

        ob_start();

        if ($display_tokenization) {
            $this->tokenization_script();
            $this->saved_payment_methods();
        }

        $this->elements_form($display_tokenization);

        ob_end_flush();
    }

    /**
     * Renders the Nexio elements form.
     */
    public function elements_form($display_tokenization)
    {   ?>
        <fieldset id="wc-<?php echo esc_attr($this->id); ?>-cc-form" class="wc-credit-card-form wc-payment-form">
            <?php if (! $this->is_nexio_gateway_available()) : ?>
                <p>You have reached the permitted amount of credit cards on your account.</p>
            <?php else : ?>

            <?php do_action('woocommerce_credit_card_form_start', $this->id); ?>
            <div id="wc-<?php echo esc_attr($this->id); ?>-payment-form">
                <div id="wc-nexio-loader" class="nexio-loader-element nexio-loader"></div>
                <div id="wc-nexio-loader-msg" class="nexio-loader-element nexio-loader-msg">Making secure connection</div>
                <div id="wc-nexio-iframe-wrapper" style="display:none;"></div>
                
                <?php 
                    if ($display_tokenization && ! is_add_payment_method_page() && ! isset($_GET['change_payment_method'])) {
                        $this->save_payment_method_checkbox();
                    }
                ?>
            </div>
            <?php do_action( 'woocommerce_credit_card_form_end', $this->id ); ?>
            <div class="clear"></div>

            <?php endif; ?>
        </fieldset>
        <?php
    }

    /**
     * Creates an api to be called from 3DS page nexio_after_three_ds hook
     *
     */
    public function nexio_after_three_ds()
    {
        $id = $_GET["id"];
        $hid = $_GET["hid"];
        $order_id = $_GET["orderNumber"];

        $secretKey = $this->get_option('secret');
        $key = hash_hmac('sha256', $order_id, $secretKey);

        if ($key !== $hid || !isset($id)) {
            $checkoutPage = wc_get_checkout_url();
            wp_redirect(add_query_arg('payment_error', "payment_fail", $checkoutPage));
        } else {
            $order = wc_get_order($order_id);
            $order->update_status('processing');
            wp_redirect($this->get_return_url($order));
        }
    }

    /**
     * Get nexio transaction status
     *
     * @param object $response Nexio_Response
     * @return string
     */
    public function get_transaction_status($response)
    {
        if (!empty($response->error)) {
            return $response->gatewayResponse->status;
        }

        return in_array($response->transactionStatus, ['pending', 'settled'])
            ? 'processing'
            : $response->transactionStatus;
    }

    /**
     * Checks if customer requested to save the payment method
     *
     * @return bool
     */
    public function save_payment_method_requested()
    {
        return isset($_POST['wc-nexio-new-payment-method'])
            && ! empty($_POST['wc-nexio-new-payment-method'])
            && (isset($_POST['nexio_token']) && ! empty($_POST['nexio_token']))
            && (! isset($_POST['wc-nexio-payment-token'])
                || $_POST['wc-nexio-payment-token'] === 'new');
    }

    /**
     * Save the payment method
     *
     * @return void
     */
    public function save_payment_method()
    {
        $nexio_token = WC_Nexio_Request::get_nexio_token_from_request();
        $wc_payment_token = new WC_Payment_Token_CC();

        $wc_payment_token->set_token($nexio_token['token']);
        $wc_payment_token->set_gateway_id($this->id);
        $wc_payment_token->set_last4($nexio_token['last4']);
        $wc_payment_token->set_expiry_year($nexio_token['expiry_year']);
        $wc_payment_token->set_expiry_month($nexio_token['expiry_month']);
        $wc_payment_token->set_card_type($nexio_token['card_type']);
        $wc_payment_token->set_user_id(get_current_user_id());

        $wc_payment_token->save();
    }

    /**
     * Process the payment
     *
     * @param int  $order_id Reference.
     *
     * @throws Exception If payment will not be accepted.
     * @return array
     */
    public function process_payment($order_id)
    {
        $order = wc_get_order($order_id);

        try {
            $result = WC_Nexio_Request::nexio_payment($order);
            $order->set_transaction_id($result->data->id);
            $response_data = $result->data;
            $transaction_status = $this->get_transaction_status($response_data);

            if ($result->statusCode === 200) {
                $order->update_status($transaction_status);
                $redirect = !empty($response_data->redirectUrl) ? $response_data->redirectUrl : $this->get_return_url($order);

                // Remove cart.
                if (isset(WC()->cart)) {
                    WC()->cart->empty_cart();
                }

                if ($this->save_payment_method_requested()) {
                    $this->save_payment_method();
                }

                WC_Nexio_Logger::log("Processing payment successful!\nOrder Number={$response_data->data->customer->orderNumber}\nAmount={$response_data->amount}\nAuthCode={$response_data->authCode}\nCard=****{$response_data->token->lastFour}\nTransaction Status={$response_data->transactionStatus}\nTransaction Date={$response_data->transactionDate}");

                return array(
                    'result' => 'success',
                    'redirect' => $redirect
                );
            } else {
                WC_Nexio_Logger::log("HTTP Code: {$result->statusCode}\nNexio Error: {$result->error}\nGateway Error: {$response_data->error}\nGateway Message: {$response_data->message}");
                throw new ErrorException($result->error);
            }
        } catch (Exception $e) {
            error_log("Processing payment:" . $e->getMessage(), 0);
            WC_Nexio_Logger::log("Processing Error: {$e->getMessage()}");
            $order->update_status('failed');
            wc_add_notice(__('Payment error: ', 'woothemes') . "Transaction Declined: " . WC_Nexio_Helper::get_nexio_error($e->getMessage()), 'error');

            return [
                'result'   => 'fail',
                'redirect' => ''
            ];
        }
    }

    /**
     * Add payment method via account screen. This should be extended by gateway plugins.
     *
     * @since 3.2.0 Included here from 3.2.0, but supported from 3.0.0.
     * @return array
     */
    public function add_payment_method()
    {
        $this->save_payment_method();

        return array(
            'result'   => 'success',
            'redirect' => wc_get_endpoint_url('payment-methods'),
        );
    }

    /**
     * Get boolean equivalent of an option
     *
     * @return boolean
     */
    protected function get_option_boolean($field)
    {
        return $this->get_option($field) === 'yes';
    }

    public function can_refund_order($order): bool
    {
        return true;
    }

    public function process_refund($order_id, $amount = null, $reason = '')
    {
        $order = wc_get_order($order_id);

        if (!$order) {
            return false;
        }

        $transaction_id = $order->get_transaction_id();
        $response = WC_Nexio_Request::nexio_refund($transaction_id, $amount);

        if ($response->statusCode === 200) {
            return true;
        } else {
            return new WP_Error(
                'nexio_error',
                sprintf(
                    __('Status Code: %1$s - There was a problem initiating a refund: %2$s', 'woocommerce-gateway-nexio'),
                    $response->statusCode, $response->error
                )
            );
        }
    }
}
