<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provides static methods as helpers.
 *
 * @since 4.0.0
 */
class WC_Nexio_Helper {

    public static function console_log($output, $with_script_tags = true) {
        $js_code = 'console.log(' . json_encode($output, JSON_HEX_TAG) . ');';
        if ($with_script_tags) {
            $js_code = '<script>' . $js_code . '</script>';
        }
        echo $js_code;
    }

    /**
     * Get Nexio error message
     *
     * @param string $error
     * @return string
     */
    public static function get_nexio_error($error) {
        if (strpos($response, 'Card number error') !== false) {
            return 'Card declined, card information entered is incorrect.';
        } elseif (strpos($response, 'Do not Honor') !== false) {
            return 'Card declined, please use another card.';
        } elseif (strpos($response, 'Credit card has expired') !== false) {
            return 'Card declined, card information entered is incorrect.';
        } elseif (strpos($response, 'Insufficient funds') !== false) {
            return 'Card declined, insufficient funds.';
        } elseif (strpos($response, 'Verify CVC Failed') !== false) {
            return 'Card declined, card information entered is incorrect.';
        } elseif (strpos($response, 'Unauthorized') !== false) {
            return 'Unauthorized credentials. Please contact support.';
        } elseif (strpos($response, 'Kount error') !== false) {
            return 'Please try with a different card.';
        } else {
            return 'Card declined, card information entered is incorrect.';
        }
    }
}
