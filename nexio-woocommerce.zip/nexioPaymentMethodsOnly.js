// The following Variables are declaired in the nexio.php file
// const existingTokens
// const otu
// const postPaymentUrl;
// const returnUrl;
// paymentMethodPage
// const domainUrl;
// const basicAuth;

let formValid = false;
const nexioIframeParent = window.document.getElementById('nexio-iframe');

function saveCardToken(nexioData) {
    //Check if the user requested to save the card
    nexioData.customerRequestsCardSave = true;
    fetch(postPaymentUrl, {
        method: 'POST',
        body: JSON.stringify(nexioData),
        headers: {
            'Content-Type': 'application/json',
            'Authorization': basicAuth
        }
    }).then(() => {
        window.location.replace(paymentMethodPage);
    }).catch((e) => {
        console.error('Error tokenizing card', e);
        nexioIframeParent.innerHTML = '<p>Error contacting payment provider please reload cart.</p>';
    });
}

function loaderState(state, nexioLoader, nexioLoaderMsg, nexioTokenDiv) {
    if (state === 'loaded') {
        nexioLoader.style.display = 'none';
        nexioLoaderMsg.style.display = 'none';
        nexioLoaderMsg.innerHTML = '';
    } else if (state === 'loading') {
        nexioLoader.style.display = 'block';
        nexioLoaderMsg.style.display = 'block';
        nexioLoaderMsg.innerHTML = '';
    } else if (state === 'processing') {
        nexioLoader.style.display = 'block';
        nexioLoaderMsg.style.display = 'block';
        nexioLoaderMsg.innerHTML = 'processing';
    } else if (state === 'error') {
        nexioLoader.style.display = 'none';
        nexioLoaderMsg.style.display = 'block';
        nexioLoaderMsg.innerHTML = 'Error contacting payment provider please reload cart';
    }
}

window.addEventListener('message', function messageListener(event) {
    const nexioLoader = window.document.getElementById('nexio-loader');
    const nexioLoaderMsg = window.document.getElementById('nexio-loader-msg');
    const nexioPaymentForm = window.document.getElementById('nexio-payment-form');
    const nexioTokenDiv = window.document.getElementById('nexio-token-pg');

    // make sure we are listening to the write url
    if (event.origin + '/pay' === domainUrl) {
        //make sure all of the credit fields are ok to submit
        if (event.data.event === 'formValidations') {
            formValid = event.data.data.isFormValid;
            // do not display loading if we ccfound form errors
            if (!formValid) {
                loaderState('loaded', nexioLoader, nexioLoaderMsg, nexioTokenDiv);
                window.document.getElementById('nexio-payment-form').style.visibility = 'unset';
            }
        }
        // iframe told us that a card was tokenized so save card to wordpress and show spinner
        if (event.data.event === 'cardSaved') {
            saveCardToken(event.data);
        }

        if (event.data.event === 'error') {
            loaderState('error', nexioLoader, nexioLoaderMsg, nexioTokenDiv);
        }

        // the nexio form loaded so prepare the initial view state of the plugin
        if (event.data.event === 'loaded') {
            let placeOrderButton = window.document.getElementById('place_order');
            if (placeOrderButton) {

                placeOrderButton.addEventListener('click', function () {
                    event.preventDefault();
                    const nexioIframe2 = window.document.getElementById('nexio-iframe');

                    // tell nexio to submit the credit card form and show loading
                    nexioIframe2.contentWindow.postMessage('posted', '*');
                    loaderState('processing', nexioLoader, nexioLoaderMsg);
                    window.document.getElementById('nexio-payment-form').style.visibility = 'hidden';
                    window.document.getElementById('nexio-token-pg').style.display = 'none';
                    // prevent double submit of form using wrong button

                    return false;
                });
            }

            loaderState('loaded', nexioLoader, nexioLoaderMsg);
            nexioPaymentForm.classList.remove('hidden');
        }
    }
});
