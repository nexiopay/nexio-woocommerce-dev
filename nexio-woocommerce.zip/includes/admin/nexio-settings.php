<?php
if (!defined('ABSPATH')) {
    exit;
}

$nexio_unauthenticated_settings = [
    'enabled' => [
        'title' => __('Enable/Disable', 'cms-gateway-nexio'),
        'label' => __('Enable Nexio', 'cms-gateway-nexio'),
        'type' => 'checkbox',
        'description' => 'Make sure checkbox is enabled to start processing',
        'default' => 'no',
        'desc_tip' => true,
    ],
    'title' => [
        'title' => __('Title', 'cms-gateway-nexio'),
        'type' => 'text',
        'description' => __('This field controls the title which the user sees during checkout. It can be changed to give a better experience to the user', 'cms-gateway-nexio'),
        'default' => __('Credit Card', 'cms-gateway-nexio'),
        'desc_tip' => true,
    ],
    'description' => [
        'title' => __('Description', 'cms-gateway-nexio'),
        'type' => 'text',
        'description' => __('This field explains how the plugin is used.', 'cms-gateway-nexio'),
        'default' => __('Pay with your credit card.', 'cms-gateway-nexio'),
        'desc_tip' => true,
    ],
    'user_name' => [
        'title' => __('User Name', 'cms-gateway-nexio'),
        'label' => __('', 'cms-gateway-nexio'),
        'type' => 'text',
        'description' => __('This is the Nexio API username that is needed to route transactions correctly. Contact Nexio for support', 'cms-gateway-nexio'),
        'default' => '',
        'desc_tip' => true,
    ],
    'password' => [
        'title' => __('Password', 'cms-gateway-nexio'),
        'label' => __('', 'cms-gateway-nexio'),
        'type' => 'password',
        'description' => __('This is the Nexio API password that is needed to route transactions correctly. Contact Nexio for support', 'cms-gateway-nexio'),
        'default' => '',
        'desc_tip' => true,
    ]
];

$nexio_authenticated_settings = [
    'merchant_id' => [
        'title' => __('Merchant Id', 'cms-gateway-nexio'),
        'label' => __('', 'cms-gateway-nexio'),
        'type' => 'text',
        'description' => __('Merchant ID of the Nexio Account. It routes transactions to MerchantID in this field. ', 'cms-gateway-nexio'),
        'default' => '',
        'desc_tip' => true,
    ],
    'css' => [
        'title' => __('CSS', 'cms-gateway-nexio'),
        'label' => __('', 'cms-gateway-nexio'),
        'type' => 'text',
        'description' => __('CSS capability allows the merchant to add their own CSS UX. Please contact Nexio Support for further assistance', 'cms-gateway-nexio'),
        'default' => '',
        'desc_tip' => true,
    ],
    'customtext_url' => [
        'title' => __('Custom Text File', 'cms-gateway-nexio'),
        'label' => __('', 'cms-gateway-nexio'),
        'type' => 'text',
        'description' => __('A JSON document of translations or custom labels can be added to the plugin. Contact Nexio Support', 'cms-gateway-nexio'),
        'default' => '',
        'desc_tip' => true,
    ],
    'webhookUrl' => [
        'title' => __('Success webhook URL', 'cms-gateway-nexio'),
        'label' => __('', 'cms-gateway-nexio'),
        'type' => 'text',
        'description' => __('A webhook to call after a successful API Call. Contact Nexio Support for further assistance', 'cms-gateway-nexio'),
        'default' => '',
        'desc_tip' => true,
    ],
    'tokenWebhookUrl' => [
        'title' => __('Tokenization webhook URL', 'cms-gateway-nexio'),
        'label' => __('', 'cms-gateway-nexio'),
        'type' => 'text',
        'description' => __('A webhook to call after a tokenization successful API Call', 'cms-gateway-nexio'),
        'default' => '',
        'desc_tip' => true,
    ],
    'failWebhookUrl' => [
        'title' => __('Fail webhook URL', 'cms-gateway-nexio'),
        'label' => __('', 'cms-gateway-nexio'),
        'type' => 'text',
        'description' => __('A webhook to call after a failed API Call. Contact Nexio Support for further assistance', 'cms-gateway-nexio'),
        'default' => '',
        'desc_tip' => true,
    ],
    'tokenFailWebhookUrl' => [
        'title' => __('Fail Tokenization webhook URL', 'cms-gateway-nexio'),
        'label' => __('', 'cms-gateway-nexio'),
        'type' => 'text',
        'description' => __('A webhook to call after a failed tokenization API Call. Contact Nexio Support for further assistance', 'cms-gateway-nexio'),
        'default' => '',
        'desc_tip' => true,
    ],
    'secret' => [
        'title' => __('Message Secret', 'cms-gateway-nexio'),
        'label' => __('', 'cms-gateway-nexio'),
        'type' => 'text',
        'description' => __('A secret value used to secure messages. Contact Nexio Support for further assistance', 'cms-gateway-nexio'),
        'default' => '',
        'desc_tip' => true
    ],
    'requirecvc' => array(
        'title' => __('Require Security Code', 'cms-gateway-nexio'),
        'label' => __('Check this field to require CVC/Security code for each transaction. Contact Nexio Support', 'cms-gateway-nexio'),
        'type' => 'checkbox',
        'description' => '',
        'default' => 'yes',
        'desc_tip' => true,
    ),
    'check3ds' => array(
        'title' => __('Check 3DS', 'cms-gateway-nexio'),
        'label' => __('3DS, or three-domain secure, helps prevent fraud by requiring cardholders to authenticate with their issuing bank when making online purchases', 'cms-gateway-nexio'),
        'type' => 'checkbox',
        'description' => '3D Secure bank verification for fraud prevention',
        'default' => 'no',
        'desc_tip' => true
    ),
    'hidecvc' => array(
        'title' => __('Hide Security Code', 'cms-gateway-nexio'),
        'label' => __('Check this field to hide CVC/Security code for each transaction. Contact Nexio Support', 'cms-gateway-nexio'),
        'type' => 'checkbox',
        'description' => '',
        'default' => 'no',
        'desc_tip' => true,
    ),
    'hidebilling' => array(
        'title' => __('Hide Billing', 'cms-gateway-nexio'),
        'label' => __('Check this field to hide the Billing info from displaying at checkout. Contact Nexio Support', 'cms-gateway-nexio'),
        'type' => 'checkbox',
        'description' => '',
        'default' => 'yes',
        'desc_tip' => true,
    ),
    'sendCountryAsTag' => array(
        'title' => __('Send country as tag', 'cms-gateway-nexio'),
        'label' => __('Check this field to allow support for country routing transactions. Contact Nexio Support for further assistance', 'cms-gateway-nexio'),
        'type' => 'checkbox',
        'description' => '',
        'default' => 'no',
        'desc_tip' => true,
    ),
    'authonly' => array(
        'title' => __('Auth Only', 'cms-gateway-nexio'),
        'label' => __('Check this field to process Auth Only transactions. Contact Nexio Support', 'cms-gateway-nexio'),
        'type' => 'checkbox',
        'description' => '',
        'default' => 'no',
        'desc_tip' => true,
    )
];

$settings = WC_Nexio_Request::get_settings();

$username = isset($settings['user_name']) ? $settings['user_name'] : '';
$password = isset($settings['password']) ? $settings['password'] : '';
$nexio_settings = [];

if (empty($username) || empty($password)) {
    $nexio_settings = $nexio_unauthenticated_settings; 
} else {
    $whoAmI = WC_Nexio_Request::whoami();

    if (empty($whoAmI->whoami) || !isset($whoAmI->whoami->accountId)) {
        $nexio_settings['validcreds'] = [
            'title' => __('', 'cms-gateway-nexio'),
            'label' => __('<strong style="color:red;">Invalid credentials. Please try again or contact Nexio Support.</strong>', 'cms-gateway-nexio'),
            'type' => 'checkbox',
            'css' => 'display: none;',
            'default' => 'no',
        ];

        $nexio_settings = array_merge($nexio_settings, $nexio_unauthenticated_settings);
    } else {
        $nexio_settings = array_merge($nexio_unauthenticated_settings, $nexio_authenticated_settings);

        if (isset($whoAmI->merchant[0]->kountMerc) && !empty($whoAmI->merchant[0]->kountMerc)) {
            $nexio_settings['fraud'] = [
                'title' => __('Fraud Check', 'cms-gateway-nexio'),
                'label' => __('Contact your Nexio sales agent for more information, or if you are interested in using fraud tools with your Nexio merchant account.', 'cms-gateway-nexio'),
                'type' => 'checkbox',
                'description' => 'Contact your Nexio sales agent for more information, or if you are interested in using fraud tools with your Nexio merchant account.',
                'default' => 'no',
                'desc_tip' => true,
            ];
        }

        if (isset($whoAmI->whoami->isEnabledForAccountUpdater) && $whoAmI->whoami->isEnabledForAccountUpdater) {
            $nexio_settings['accountUpdater'] = [
                'title' => __('Account Updater', 'cms-gateway-nexio'),
                'label' => __('The account updater service allows merchants to automatically update saved cards due to changes in card numbers or expiration dates.', 'cms-gateway-nexio'),
                'type' => 'checkbox',
                'description' => 'Merchants that process recurring transactions will see fewer declines due to invalid or expired cards by having the most recent card information before the transaction is attempted. Contact Nexio for more information',
                'default' => 'no',
                'desc_tip' => true,
            ];
        }
    }
}

return apply_filters(
    'wc_nexio_settings',
    array_merge($nexio_settings, [
        'testmode' => [
            'title' => __('Test Mode', 'cms-gateway-nexio'),
            'label' => __('Enable Test Mode. Contact Nexio Support for further assistance.', 'cms-gateway-nexio'),
            'type' => 'checkbox',
            'description' => '',
            'default' => 'no',
            'desc_tip' => true,
        ],
        'logging'  => [
            'title'       => __('Logging', 'cms-gateway-nexio'),
            'label'       => __('Log debug messages', 'cms-gateway-nexio'),
            'type'        => 'checkbox',
            'description' => __('Save debug messages to the WooCommerce System Status log.', 'cms-gateway-nexio'),
            'default'     => 'no',
            'desc_tip'    => true,
        ]
    ])
);