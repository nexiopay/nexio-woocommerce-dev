// The following Variables are declaired in the nexio.php file
// const existingTokens
// const postPaymentUrl;
// const postSelectionUrl;
// const returnUrl;
// const domainUrl;
// const basicAuth;

let formValid = false;
let cctoken = null;
let isFormRequest = false;
const nexioIframeParent = window.document.getElementById('order_review');
let savedCardTokens = haveTokens(existingTokens);

function showButton(buttonType, nexioPaySubmit, wordpressCustomPaySubmit) {
    if (buttonType === 'nexio' && wordpressCustomPaySubmit) {
        nexioPaySubmit.disabled = false;
        wordpressCustomPaySubmit.disabled = true;
        wordpressCustomPaySubmit.style.visibility = 'hidden';
        nexioPaySubmit.style.visibility = 'unset';
    } else if (buttonType === 'woo' && wordpressCustomPaySubmit) {
        nexioPaySubmit.disabled = true;
        wordpressCustomPaySubmit.disabled = false;
        wordpressCustomPaySubmit.style.visibility = 'unset';
        nexioPaySubmit.style.visibility = 'hidden';
    }
}

function haveTokens(data) {
    if (typeof data === 'object' && data !== null && userLoggedIn) {
        return data;
    } else {
        return false;
    }
}

function saveCardToken(nexioData, nexioPaySubmit, wordpressCustomPaySubmit, cardHolderName) {
    //Check if the user requested to save the card
    let nexioSaveCardCheckbox = window.document.getElementById('nexio-save-card-checkbox');
    nexioData.customerRequestsCardSave = nexioSaveCardCheckbox.checked;
    fetch(postPaymentUrl, {
        method: 'POST',
        body: JSON.stringify(nexioData),
        headers: {
            'Content-Type': 'application/json',
            'Authorization': basicAuth
        }
    }).then(() => {
        if (formValid) {
            showButton('woo', nexioPaySubmit, wordpressCustomPaySubmit);
            wordpressCustomPaySubmit.click();
        }
    }).catch((e) => {
        console.error('Error tokenizing card', e);
        nexioIframeParent.innerHTML = '<p>Error contacting payment provider please reload cart.</p>';
    });
}

function isDefaultPaymentMethod(token) {
    if(token.data.is_default) {
        return 'checked = true';
    } else{
        return ''
    }
}

function getSelectedCardTokenId() {
    var ele = window.document.getElementsByName('nexio-card-item');
    for(i = 0; i < ele.length; i++) {
        if(ele[i].checked)
        return savedCardTokens[i].data.id;
    }
    return null;
}

function unselectDefaultCard() {
    var ele = window.document.getElementsByName('nexio-card-item');
    for(i = 0; i < ele.length; i++) {
        if(ele[i].checked) {
            ele[i].checked = false;
            return;   
        }
    }
}

function getUserCardsInnerHTML(tokens) {
    html = '<div class="nexio-card-list">';
    tokens.forEach( function(token, index, array) {
        isDefault =  token.data.is_default ? ' <em class ="nexio-default-card">(Default)</em>' : '';
        if(token.data.card_type === 'masterCard'){
            cardHTML = '<div class="nexio-card-item"> <input type="radio" ' + isDefaultPaymentMethod(token) + ' class="nexio-card-radio" required id="nexio-card-' + index +'" name="nexio-card-item" value="MasterCard ending in ' + token.data.last4 + ' "/> <i class="fa fa-cc-mastercard"></i> <label for="nexio-card-' + index + '">MasterCard ending in ' + token.data.last4 + isDefault +'</label></div>';
            html = html + cardHTML;
        }else if(token.data.card_type === 'discover'){
            cardHTML = '<div class="nexio-card-item"> <input type="radio" ' + isDefaultPaymentMethod(token) + ' class="nexio-card-radio" required id="nexio-card-' + index +'" name="nexio-card-item" value="Discover ending in ' + token.data.last4 + ' "/> <i class="fa fa-cc-discover"></i> <label for="nexio-card-' + index + '">Discover ending in ' + token.data.last4 + isDefault +'</label></div>';
            html = html + cardHTML;
        }else if(token.data.card_type === 'visa'){
            cardHTML = '<div class="nexio-card-item"> <input type="radio" ' + isDefaultPaymentMethod(token) + ' class="nexio-card-radio" required id="nexio-card-' + index +'" name="nexio-card-item" value="Visa ending in ' + token.data.last4 + ' "/> <i class="fa fa-cc-visa"></i> <label for="nexio-card-' + index + '">Visa ending in ' + token.data.last4 + isDefault +'</label></div>';
            html = html + cardHTML;
        }
        else if(token.data.card_type === 'americanExpress'){
            cardHTML = '<div class="nexio-card-item"> <input type="radio" ' + isDefaultPaymentMethod(token) + ' class="nexio-card-radio" required id="nexio-card-' + index +'" name="nexio-card-item" value="Amex ending in ' + token.data.last4 + ' "/> <i class="fa fa-cc-amex"></i> <label for="nexio-card-' + index + '">Amex ending in ' + token.data.last4 + isDefault +'</label></div>';
            html = html + cardHTML;
        }
    });
    html = html + '</div>';

    if ( tokens.length < maxPaymentMethods){
        html = html + '<div><a class="nexio-add-card-link" id="nexio-add-card-link">New Card</a></div>';
    }else{
        html = html + `<div ><span title="You have reached the permitted amount of credit cards on your account" class="nexio-add-card-link-maxreached" >New Card</span><span class="nexio-add-card-span-maxreached">You have reached the permitted amount of credit cards on your account</span></div>`;
    }

    return html;
}

// if a user is signed in then display the last 5 cards on the page
function addTokenDataToPage(tokenDiv, nexioPaymentForm, nexioPaySubmit, wordpressCustomPaySubmit) {
    if(userLoggedIn){
        if(!nexioPaySubmit || !wordpressCustomPaySubmit){
            tokenDiv.innerHTML = '<div class="nexio-theme-error"><img src="../wp-content/plugins/nexio-woocommerce/assets/nexio-error.png"/></div><div><p><strong>Error:</strong> Incompatible or custom theme detected. Please try another theme or contact Nexio support for more information.</p></div>'
        }else{
        const end = savedCardTokens[0].data.last4 || savedCardTokens[0].data.lastFour;
        getUserCardsInnerHTML(savedCardTokens);
        tokenDiv.innerHTML = getUserCardsInnerHTML(savedCardTokens);
    }
    const nexioAddCardLink = window.document.getElementById('nexio-add-card-link');
    tokenDiv.style.display = 'block';
    if (nexioAddCardLink) {
        nexioAddCardLink.addEventListener('click', () => {
        tokenDiv.style.display = 'none';
        nexioPaymentForm.style.display = 'block';
        unselectDefaultCard();
        isFormRequest = true;
        showButton('nexio', nexioPaySubmit, wordpressCustomPaySubmit);
        setSaveCardCheckBoxVisible();
    });
    }
}
}

// If a user is signed in then display the save card checkbox
function setSaveCardCheckBoxVisible() {
    if (userLoggedIn) {
        window.document.getElementById('nexio-save-card-checkbox').style.visibility = 'visible';
        window.document.getElementById('nexio-card-save-checkbox-label').style.visibility = 'visible';
        if(window.document.getElementById('nexio-card-save-checkbox-label-subscription')){
            window.document.getElementById('nexio-card-save-checkbox-label-subscription').style.visibility = 'visible';
        }
    }
}

// Check for an specific Gateway error so we may add another codes later
function checkGatewayError() {
    var alertElement = window.document.getElementsByClassName('woocommerce-error');
    if (alertElement[0]) {
        if (alertElement[0].innerHTML.replace(/\s+/g, '').includes('Error:')) {
            const nexioAddCardLink = window.document.getElementById('nexio-add-card-link');
            return true;
        } else if (alertElement[0].innerHTML.replace(/\s+/g, '').includes('TransactionDeclined:')) {
            return true;
        }
    } else {
        return false;
    }
}

$(document).ready(function ($) {
    $(document.body).on('checkout_error', function () {
        if (checkGatewayError()) {
            cctoken = null;
            isFormRequest = false;
            savedCardTokens = haveTokens(existingTokens);
            $(window.document.body).trigger('update_checkout');
        }
    });
});

function loaderState(state, nexioLoader, nexioLoaderMsg, nexioTokenDiv) {
    let customerRequestsCardSave = window.document.getElementById('nexio-save-card-checkbox').checked;
    if (state === 'loaded') {
        nexioLoader.style.display = 'none';
        nexioLoaderMsg.style.display = 'none';
        nexioLoaderMsg.innerHTML = '';
    } else if (state === 'tokenized' && userLoggedIn && customerRequestsCardSave) {
        nexioTokenDiv.innerHTML = '<div>  Card ending in ' + end + '</div>';
        nexioTokenDiv.style.display = 'block';
        nexioLoader.style.display = 'none';
        nexioLoaderMsg.style.display = 'none';
    } else if(state === 'tokenized' && userLoggedIn || !userLoggedIn && !customerRequestsCardSave) {
        const end = savedCardTokens.last4 || savedCardTokens.lastFour;
        const nexioTokenDiv = window.document.getElementById('nexio-token-pg');
        nexioTokenDiv.innerHTML = '<div>  Card ending in ' + end + '</div>';
        nexioTokenDiv.style.display = 'block';
        nexioLoader.style.display = 'none';
        nexioLoaderMsg.style.display = 'none';
    } else if (state === 'loading') {
        nexioLoader.style.display = 'block';
        nexioLoaderMsg.style.display = 'block';
        nexioLoaderMsg.innerHTML = '';
    } else if (state === 'processing') {
        nexioLoader.style.display = 'block';
        nexioLoaderMsg.style.display = 'block';
        nexioLoaderMsg.innerHTML = 'processing';
    } else if (state === 'error') {
        nexioLoader.style.display = 'none';
        nexioLoaderMsg.style.display = 'block';
        nexioLoaderMsg.innerHTML = 'Error contacting payment provider please reload cart';
    }
}

const urlSearchParams = new URLSearchParams(window.location.search);
const params = Object.fromEntries(urlSearchParams.entries());
if (params.hasOwnProperty('payment_error')) {
    const page = window.document.getElementById('content');
    const errorNode = document.createElement('div');
    errorNode.classList.add('nexio-error');
    page.appendChild(errorNode);
    const newContent = document.createTextNode('Your payment has been declined.');
    errorNode.appendChild(newContent);
    setTimeout(() => {
        errorNode.classList.add('nexio-fade');
    }, 5000);
}

window.addEventListener('message', function messageListener(event) {
    const nexioLoader = window.document.getElementById('nexio-loader');
    const nexioLoaderMsg = window.document.getElementById('nexio-loader-msg');
    const nexioPaymentForm = window.document.getElementById('nexio-payment-form');

    const paymentMethodRadios = window.document.getElementsByName('payment_method');
    const nexioPaySubmit = window.document.getElementById('nexio-pay-submit');
    const wordpressCustomPaySubmit = window.document.getElementById('wordpress-custom-pay-submit');
    const nexioRadio = window.document.getElementById('payment_method_nexio');
    const nexioTokenDiv = window.document.getElementById('nexio-token-pg');

    // make sure we are listening to the write url
    if (event.origin + '/pay' === domainUrl) {
        //make sure all of the credit fields are ok to submit
        if (event.data.event === 'formValidations') {
            formValid = event.data.data.isFormValid;
            // do not display loading if we ccfound form errors
            if (!formValid) {
                loaderState('loaded', nexioLoader, nexioLoaderMsg, nexioTokenDiv);
                const nexioSubmit = window.document.getElementById('nexio-pay-submit');
                //re enable the button there are errors it was disabled to prevent double submit of form using wrong button
                if (nexioSubmit) {
                    nexioSubmit.disabled = false;
                }
                window.document.getElementById('nexio-payment-form').style.visibility = 'unset';
            }
        }
        // iframe told us that a card was tokenized so save card to wordpress and show spinner
        if (event.data.event === 'cardSaved') {
            savedCardTokens = event.data.data.token;
            cardHolderName = event.data.data.card.cardHolderName;
            saveCardToken(event.data, nexioPaySubmit, wordpressCustomPaySubmit, cardHolderName);
            cctoken = event.data.data.token.token;
            loaderState('tokenized', nexioLoader, nexioLoaderMsg, nexioTokenDiv);
        }

        if (event.data.event === 'error') {
            loaderState('error', nexioLoader, nexioLoaderMsg, nexioTokenDiv);
        }

        // the nexio form loaded so prepare the initial view state of the plugin
        if (event.data.event === 'loaded') {
            let prev = null;
            for (let i = 0; i < paymentMethodRadios.length; i++) {
                paymentMethodRadios[i].addEventListener('change', function () {
                    if (this !== prev) {
                        prev = this;
                    }
                    if (this.value === 'nexio') {
                        showButton('nexio', nexioPaySubmit, wordpressCustomPaySubmit);
                    } else {
                        showButton('woo', nexioPaySubmit, wordpressCustomPaySubmit);
                    }
                });
            }
            if(savedCardTokens.length !== 0 && savedCardTokens[0] !== typeof undefined && userLoggedIn || cctoken){
                addTokenDataToPage(nexioTokenDiv, nexioPaymentForm, nexioPaySubmit, wordpressCustomPaySubmit);
            } else {
                savedCardTokens = haveTokens(existingTokens);
                if(savedCardTokens.data){
                    addTokenDataToPage(nexioTokenDiv, nexioPaymentForm, nexioPaySubmit, wordpressCustomPaySubmit);
                }else{
                    if(!nexioPaySubmit || !wordpressCustomPaySubmit){
                        nexioPaymentForm.style.display = 'none';
                        const nexioTokenDiv = window.document.getElementById('nexio-token-pg');
                        nexioTokenDiv.innerHTML = '<div class="nexio-theme-error"><img src="../wp-content/plugins/nexio-woocommerce/assets/nexio-error.png"/></div><div><p><strong>Error:</strong> Incompatible or custom theme detected. Please try another theme or contact Nexio support for more information.</p></div>';
                        nexioTokenDiv.style.display = 'block';
                        throw new Error('There was an error with the current theme.');
                    }
                isFormRequest = true;
                showButton('nexio', nexioPaySubmit, wordpressCustomPaySubmit);
                }
            }

            //start off by using nexio click on form so all view states are set
            nexioRadio.checked = true;
            nexioRadio.click();

            //if the user had already saved a credit card so hide the credit card form
            if (savedCardTokens.length !== 0 && userLoggedIn) {
                nexioPaymentForm.style.display = 'none';
                showButton('nexio', nexioPaySubmit, wordpressCustomPaySubmit);
            } else {
                nexioTokenDiv.style.display = 'none';
                showButton('nexio', nexioPaySubmit, wordpressCustomPaySubmit);
                setSaveCardCheckBoxVisible();
            }

            if (window.document.getElementById('nexio-pay-submit')) {
                window.document.getElementById('nexio-pay-submit').addEventListener('click', function () {
                    event.preventDefault();
                    jQuery('.validate-required input, .validate-required select').trigger('validate');
                    const nexioIframe2 = window.document.getElementById('nexio-iframe');
                    //the front end already has a nexio token submit the wordpress from now
                    if (cctoken) {
                        const hiddenSubmit = window.document.getElementById('wordpress-custom-pay-submit');
                        hiddenSubmit.disabled = false;
                        hiddenSubmit.click();
                    } else {
                        if(!isFormRequest && userLoggedIn) {
                            var eventData = {
                                event : 'cardSelected',
                                customerSelectedTokenId : getSelectedCardTokenId()
                            };
                            fetch(postSelectionUrl, {
                                method: 'POST',
                                body: JSON.stringify(eventData),
                                headers: {
                                    'Content-Type': 'application/json',
                                }
                            }).then((data) => {
                            }).catch((e) => {
                                console.error('There was an error with the card', e);
                                nexioIframeParent.innerHTML = '<p>Error contacting payment provider please reload cart.</p>';
                            });
                        }

                        // tell nexio to submit the credit card form and show loading
                        nexioIframe2.contentWindow.postMessage('posted', '*');
                        loaderState('processing', nexioLoader, nexioLoaderMsg);
                        window.document.getElementById('nexio-payment-form').style.visibility = 'hidden';
                        window.document.getElementById('nexio-token-pg').style.display = 'none';
                        // prevent double submit of form using wrong button
                        const nexioSubmit = window.document.getElementById('nexio-pay-submit');
                        if (nexioSubmit) {
                            nexioSubmit.disabled = true;
                        }
                        if(eventData) {
                            const hiddenSubmit = window.document.getElementById('wordpress-custom-pay-submit');
                            hiddenSubmit.disabled = false;
                            nexioSubmit.disabled = true;
                            hiddenSubmit.click();
                            }
                        eventData = null;
                    }

                    return false;
                });
            } else if (window.document.getElementById('place_order')) {
                window.document.getElementById('place_order').addEventListener('click', function () {
                    const nexioIframe2 = window.document.getElementById('nexio-iframe');
                    nexioIframe2.contentWindow.postMessage('posted', '*');
                    loaderState('processing', nexioLoader, nexioLoaderMsg);
                    window.document.getElementById('nexio-payment-form').style.visibility = 'hidden';
                    window.document.getElementById('nexio-token-pg').style.display = 'none';
                });
            }

            loaderState('loaded', nexioLoader, nexioLoaderMsg);
            nexioPaymentForm.classList.remove('hidden');
        }
    }
});