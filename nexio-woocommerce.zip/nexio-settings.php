<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!session_id() || !$_SESSION) {
    session_start();
}

// Load settings on this class before rendering options page
$this->init_settings();

if (empty(trim($this->settings['user_name'])) && empty(trim($this->settings['password']))) {
    //Empty credential fields
    return apply_filters(
        'cms_nexio_settings',
        array(
            'enabled' => array(
                'title' => __('Enable/Disable', 'cms-gateway-nexio'),
                'label' => __('Enable Nexio', 'cms-gateway-nexio'),
                'type' => 'checkbox',
                'description' => 'Make sure checkbox is enabled to start processing',
                'default' => 'no',
                'desc_tip' => true,
                'enabled' => false,
            ),
            'title' => array(
                'title' => __('Title', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('This field controls the title which the user sees during checkout. It can be changed to give a better experience to the user', 'cms-gateway-nexio'),
                'default' => __('Credit Card', 'cms-gateway-nexio'),
                'desc_tip' => true,
            ),
            'description' => array(
                'title' => __('Description', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('This field explains how the plugin is used.', 'cms-gateway-nexio'),
                'default' => __('Pay with your credit card.', 'cms-gateway-nexio'),
                'desc_tip' => true,
            ),
            'user_name' => array(
                'title' => __('User Name', 'cms-gateway-nexio'),
                'label' => __('', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('This is the Nexio API username that is needed to route transactions correctly. Contact Nexio for support', 'cms-gateway-nexio'),
                'default' => '',
                'desc_tip' => true,
            ),
            'password' => array(
                'title' => __('Password', 'cms-gateway-nexio'),
                'label' => __('', 'cms-gateway-nexio'),
                'type' => 'password',
                'description' => __('This is the Nexio API password that is needed to route transactions correctly. Contact Nexio for support', 'cms-gateway-nexio'),
                'default' => '',
                'desc_tip' => true
            )
            )
    );
} else {
    //Text on fields
    $userName = $this->settings['user_name'];
    $password = $this->settings['password'];


    $endPoint = $this->settings['developmentMode'] === 'yes' ? 'https://api.nexiopaysandbox.com' : 'https://api.nexiopay.com';

    if (empty($_SESSION['requestSent']) || !isset($_SESSION['requestSent'])  ||  (time() > ($_SESSION['requestSent'] + 10))) {
        unset($_SESSION['isEnabledForFrCheck']);
        unset($_SESSION['isEnabledForAccountUpdater']);
        unset($_SESSION['lastResponseCode']);

        $WhoAmIResponse = wp_remote_get($endPoint . '/user/v3/account/whoAmI', [
        'headers' => [
            'authorization' => 'Basic ' . base64_encode($userName . ':' . $password),
            'content-type' => 'application/json'
        ]]);

        $fResponse = wp_remote_get($endPoint . '/merchant/v3', [
            'headers' => [
                'authorization' => 'Basic ' . base64_encode($userName . ':' . $password),
                'content-type' => 'application/json'
            ]]);

        unset($_SESSION['invCreds']);
        $_SESSION['requestSent'] = time();
        $_SESSION['lastResponseCode'] = wp_remote_retrieve_response_code($WhoAmIResponse);
    }

    $responseBody = wp_remote_retrieve_body($WhoAmIResponse);
    $responseCode = wp_remote_retrieve_response_code($WhoAmIResponse);
    $result = json_decode($responseBody);

    $fResponseBody = wp_remote_retrieve_body($fResponse);
    $fResult = json_decode($fResponseBody);

    if ($responseCode !== '' && $responseCode !== 200) {
        unset($_SESSION['isEnabledForAccountUpdater']);
        unset($_SESSION['isEnabledForFrCheck']);
        unset($_SESSION['lastResponseCode']);
        $_SESSION['invCreds'] = true;
    } else {
            //Account Updater
        if (isset($result->isEnabledForAccountUpdater) && $result->isEnabledForAccountUpdater === true || isset($result->isEnabledForCybersourceAccountUpdater) && $result->isEnabledForCybersourceAccountUpdater === true || isset($_SESSION['isEnabledForAccountUpdater']) && $_SESSION['isEnabledForAccountUpdater'] === true) {
            $_SESSION['isEnabledForAccountUpdater'] = 'true';
        } elseif ($_SESSION['isEnabledForAccountUpdater'] === false || $result->isEnabledForCybersourceAccountUpdater === false) {
            $_SESSION['isEnabledForAccountUpdater'] = 'false';
        }

        $enabledFrDesc = 'Contact your Nexio sales agent for more information, or if you are interested in using fraud tools with your Nexio merchant account.' ;
        $disabledFrDesc = '<em>Feature is not active on your nexio account. Please contact nexio support for more information</em>';
        $enabledAccUpdaterDesc = 'The account updater service allows merchants to automatically update saved cards due to changes in card numbers or expiration dates.';

        //Fraud
        if (isset($fResult[0]->kountMerc) && !empty($fResult[0]->kountMerc) || (isset($_SESSION['isEnabledForFrCheck']) && $_SESSION['isEnabledForFrCheck'] === true)) {
            $_SESSION['isEnabledForFrCheck'] = 'true';
        } elseif ($_SESSION['isEnabledForFrCheck'] === false) {
            $_SESSION['isEnabledForFrCheck'] = 'false';
        }
    }



    if ($responseCode === 200 || !empty($_SESSION['lastResponseCode']) && $_SESSION['lastResponseCode'] !== 401 && $_SESSION['lastResponseCode'] !== 403) {
        return apply_filters(
            'cms_nexio_settings',
            array(
            'enabled' => array(
                'title' => __('Enable/Disable', 'cms-gateway-nexio'),
                'label' => __('Enable Nexio', 'cms-gateway-nexio'),
                'type' => 'checkbox',
                'description' => 'Make sure checkbox is enabled to start processing',
                'default' => 'no',
                'desc_tip' => true,
            ),
            'title' => array(
                'title' => __('Title', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('This field controls the title which the user sees during checkout. It can be changed to give a better experience to the user', 'cms-gateway-nexio'),
                'default' => __('Credit Card', 'cms-gateway-nexio'),
                'desc_tip' => true,
            ),
            'description' => array(
                'title' => __('Description', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('This field explains how the plugin is used.', 'cms-gateway-nexio'),
                'default' => __('Pay with your credit card.', 'cms-gateway-nexio'),
                'desc_tip' => true,
            ),
            'user_name' => array(
                'title' => __('User Name', 'cms-gateway-nexio'),
                'label' => __('', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('This is the Nexio API username that is needed to route transactions correctly. Contact Nexio for support', 'cms-gateway-nexio'),
                'default' => '',
                'desc_tip' => true,
            ),
            'password' => array(
                'title' => __('Password', 'cms-gateway-nexio'),
                'label' => __('', 'cms-gateway-nexio'),
                'type' => 'password',
                'description' => __('This is the Nexio API password that is needed to route transactions correctly. Contact Nexio for support', 'cms-gateway-nexio'),
                'default' => '',
                'desc_tip' => true,
            ),
            'merchant_id' => array(
                'title' => __('Merchant Id', 'cms-gateway-nexio'),
                'label' => __('', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('Merchant ID of the Nexio Account. It routes transactions to MerchantID in this field. ', 'cms-gateway-nexio'),
                'default' => '',
                'desc_tip' => true,
            ),
            'css' => array(
                'title' => __('CSS', 'cms-gateway-nexio'),
                'label' => __('', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('CSS capability allows the merchant to add their own CSS UX. Please contact Nexio Support for further assistance', 'cms-gateway-nexio'),
                'default' => '',
                'desc_tip' => true,
            ),
            'customtext_url' => array(
                'title' => __('Custom Text File', 'cms-gateway-nexio'),
                'label' => __('', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('A JSON document of translations or custom labels can be added to the plugin. Contact Nexio Support', 'cms-gateway-nexio'),
                'default' => '',
                'desc_tip' => true,
            ),
            'webhookUrl' => array(
                'title' => __('Success webhook URL', 'cms-gateway-nexio'),
                'label' => __('', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('A webhook to call after a successful API Call. Contact Nexio Support for further assistance', 'cms-gateway-nexio'),
                'default' => '',
                'desc_tip' => true,
            ),
            'tokenWebhookUrl' => array(
                'title' => __('Tokenization webhook URL', 'cms-gateway-nexio'),
                'label' => __('', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('A webhook to call after a tokenization successful API Call', 'cms-gateway-nexio'),
                'default' => '',
                'desc_tip' => true,
            ),
            'failWebhookUrl' => array(
                'title' => __('Fail webhook URL', 'cms-gateway-nexio'),
                'label' => __('', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('A webhook to call after a failed API Call. Contact Nexio Support for further assistance', 'cms-gateway-nexio'),
                'default' => '',
                'desc_tip' => true,
            ),
            'tokenFailWebhookUrl' => array(
                'title' => __('Fail Tokenization webhook URL', 'cms-gateway-nexio'),
                'label' => __('', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('A webhook to call after a failed tokenization API Call. Contact Nexio Support for further assistance', 'cms-gateway-nexio'),
                'default' => '',
                'desc_tip' => true,
            ),
            'secret' => array(
                'title' => __('Message Secret', 'cms-gateway-nexio'),
                'label' => __('', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => __('A secret value used to secure messages. Contact Nexio Support for further assistance', 'cms-gateway-nexio'),
                'default' => '',
                'desc_tip' => true
            ),
            $_SESSION['isEnabledForFrCheck'] === 'true' ? 'fraud' : 'dFraud' => array(
                'title' => __('Fraud Check', 'cms-gateway-nexio'),
                'label' => __($_SESSION['isEnabledForFrCheck'] === 'true' ? $enabledFrDesc : $disabledFrDesc, 'cms-gateway-nexio'),
                'type' => 'checkbox',
                'css' => $_SESSION['isEnabledForFrCheck'] === 'true' ? '' : 'display: none;',
                'description' => 'Contact your Nexio sales agent for more information, or if you are interested in using fraud tools with your Nexio merchant account.',
                'default' => 'no',
                'desc_tip' => true,
            ),
            'requirecvc' => array(
                'title' => __('Require Security Code', 'cms-gateway-nexio'),
                'label' => __('Check this field to require CVC/Security code for each transaction. Contact Nexio Support', 'cms-gateway-nexio'),
                'type' => 'checkbox',
                'description' => '',
                'default' => 'yes',
                'desc_tip' => true,
            ),
            'check3ds' => array(
                'title' => __('Check 3DS', 'cms-gateway-nexio'),
                'label' => __('3DS, or three-domain secure, helps prevent fraud by requiring cardholders to authenticate with their issuing bank when making online purchases', 'cms-gateway-nexio'),
                'type' => 'checkbox',
                'description' => '3D Secure bank verification for fraud prevention',
                'default' => 'no',
                'desc_tip' => true
            ),
            'hidecvc' => array(
                'title' => __('Hide Security Code', 'cms-gateway-nexio'),
                'label' => __('Check this field to hide CVC/Security code for each transaction. Contact Nexio Support', 'cms-gateway-nexio'),
                'type' => 'checkbox',
                'description' => '',
                'default' => 'no',
                'desc_tip' => true,
            ),
            'hidebilling' => array(
                'title' => __('Hide Billing', 'cms-gateway-nexio'),
                'label' => __('Check this field to hide the Billing info from displaying at checkout. Contact Nexio Support', 'cms-gateway-nexio'),
                'type' => 'checkbox',
                'description' => '',
                'default' => 'no',
                'desc_tip' => true,
            ),
            'sendCountryAsTag' => array(
                'title' => __('Send country as tag', 'cms-gateway-nexio'),
                'label' => __('Check this field to allow support for country routing transactions. Contact Nexio Support for further assistance', 'cms-gateway-nexio'),
                'type' => 'checkbox',
                'description' => '',
                'default' => 'no',
                'desc_tip' => true,
            ),
            'authonly' => array(
                'title' => __('Auth Only', 'cms-gateway-nexio'),
                'label' => __('Check this field to process Auth Only transactions. Contact Nexio Support', 'cms-gateway-nexio'),
                'type' => 'checkbox',
                'description' => '',
                'default' => 'no',
                'desc_tip' => true,
            ),
            $_SESSION['isEnabledForAccountUpdater'] === 'true' ? 'accountUpdater' : 'dAccountUpdater' => array(
                'title' => __('Account Updater', 'cms-gateway-nexio'),
                'label' => __($_SESSION['isEnabledForAccountUpdater'] === 'true' ? $enabledAccUpdaterDesc : $disabledFrDesc, 'cms-gateway-nexio'),
                'type' => 'checkbox',
                'css' => $_SESSION['isEnabledForAccountUpdater'] === 'true' ? '' : 'display: none;',
                'description' => 'Merchants that process recurring transactions will see fewer declines due to invalid or expired cards by having the most recent card information before the transaction is attempted. Contact Nexio for more information',
                'default' => 'no',
                'desc_tip' => true,
            ),
            'developmentMode' => array(
                'title' => __('Development Mode', 'cms-gateway-nexio'),
                'label' => __('Do not check for production transactions. Check to run DEV environment transactions. Contact Nexio Support for further assistance.', 'cms-gateway-nexio'),
                'type' => 'checkbox',
                'description' => '',
                'default' => 'no',
                'desc_tip' => true,
            ),
            'developmentBasicAuth' => array(
                'title' => __('Development Basic Auth', 'cms-gateway-nexio'),
                'label' => __('Development Basic Auth', 'cms-gateway-nexio'),
                'type' => 'text',
                'description' => 'Add Development Basic Auth support to plugin. NOT TO BE USED IN PROD',
                'default' => '',
                'desc_tip' => true,
            )
            )
        );
    } else {
        //invalid credentials
        return apply_filters(
            'cms_nexio_settings',
            array(
                'validcreds' => array(
                    'title' => __('', 'cms-gateway-nexio'),
                    'label' => __($_SESSION['invCreds'] === true ? '<strong style="color:red;">Invalid credentials. Please try again or contact Nexio Support.</strong>' : '' . '<strong><em>Supply valid credentials.</em></strong>', 'cms-gateway-nexio'),
                    'type' => 'checkbox',
                    'css' => 'display: none;',
                    'default' => 'no',
                ),
                'enabled' => array(
                    'title' => __('Enable/Disable', 'cms-gateway-nexio'),
                    'label' => __('Enable Nexio', 'cms-gateway-nexio'),
                    'type' => 'checkbox',
                    'description' => 'Make sure checkbox is enabled to start processing',
                    'default' => 'no',
                    'desc_tip' => true,
                ),
                'title' => array(
                    'title' => __('Title', 'cms-gateway-nexio'),
                    'type' => 'text',
                    'description' => __('This field controls the title which the user sees during checkout. It can be changed to give a better experience to the user', 'cms-gateway-nexio'),
                    'default' => __('Credit Card', 'cms-gateway-nexio'),
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => __('Description', 'cms-gateway-nexio'),
                    'type' => 'text',
                    'description' => __('This field explains how the plugin is used.', 'cms-gateway-nexio'),
                    'default' => __('Pay with your credit card.', 'cms-gateway-nexio'),
                    'desc_tip' => true,
                ),
                'user_name' => array(
                    'title' => __('User Name', 'cms-gateway-nexio'),
                    'label' => __('', 'cms-gateway-nexio'),
                    'type' => 'text',
                    'description' => __('This is the Nexio API username that is needed to route transactions correctly. Contact Nexio for support', 'cms-gateway-nexio'),
                    'default' => '',
                    'desc_tip' => true,
                ),
                'password' => array(
                    'title' => __('Password', 'cms-gateway-nexio'),
                    'label' => __('', 'cms-gateway-nexio'),
                    'type' => 'password',
                    'description' => __('This is the Nexio API password that is needed to route transactions correctly. Contact Nexio for support', 'cms-gateway-nexio'),
                    'default' => '',
                    'desc_tip' => true
                ),
                'developmentMode' => array(
                    'title' => __('Development Mode', 'cms-gateway-nexio'),
                    'label' => __('Do not check for production transactions. Check to run DEV environment transactions. Contact Nexio Support for further assistance.', 'cms-gateway-nexio'),
                    'type' => 'checkbox',
                    'description' => '',
                    'default' => 'no',
                    'desc_tip' => true,
                ),
                )
        );
    }
}
